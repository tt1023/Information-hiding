%椒盐噪声
% 定义 x 轴范围
x = linspace(0.05, 0.3, 6);
y1=[0.9874,0.9791,0.9681,0.9596,0.9477,0.9334];
y2=[0.9897,0.9816,0.9733,0.9634,0.9527,0.9368];
y3=[0.9873,0.9808,0.9737,0.9656,0.9518,0.9410];
y4=[0.9853,0.9743,0.9594,0.9444,0.9352,0.9083];
y5=[0.9871,0.9783,0.9715,0.9621,0.9506,0.9358];
y6=[0.9847,0.9736,0.9642,0.9501,0.9363,0.9246];
% 绘制折线图，使用不同的颜色和形状区分每条折线
figure;
hold on;
plot(x, y1, 'r-x', 'LineWidth', 0.7); 
plot(x, y2, 'c-^', 'LineWidth', 0.7); 
plot(x, y3, 'b-+', 'LineWidth', 0.7); 
plot(x, y4, 'm-o', 'LineWidth', 0.7); 
plot(x, y5, 'g-', 'Marker', 'square', 'LineWidth', 0.7);
plot(x, y6, 'b-', 'Marker', 'pentagram', 'LineWidth', 0.7);

% 设置图例和轴标签
legend('House', 'Baboon', 'Peppers', 'Airplane', 'Sailboat', 'Barbara'); % 图例
ylim([0.8, 1]);
yticks(0.8:0.02:1);
ylabel('NC');
xlabel('Density'); % x 轴标签
% grid on;  % 显示网格线
% 将四周框起来
% 设置 x 轴刻度和标签
box on
%% 高斯噪声
% 定义 x 轴范围
x = linspace(0.01, 0.035, 6);
y1=[0.9929
0.9890
0.9869
0.9855
0.9828
0.9801];
y2=[0.9938
0.9904
0.9877
0.9851
0.9830
0.9820];
y3=[0.9921
0.9889
0.9868
0.9859
0.9837
0.9823];
y4=[0.9919
0.9879
0.9853
0.9814
0.9809
0.9788];
y5=[0.9933
0.9895
0.9867
0.9834
0.9816
0.9812];
y6=[0.9905
0.9871
0.9838
0.9807
0.9786
0.9755];
% 绘制折线图，使用不同的颜色和形状区分每条折线
figure;
hold on;
plot(x, y1, 'r-x', 'LineWidth', 0.7); 
plot(x, y2, 'c-^', 'LineWidth', 0.7); 
plot(x, y3, 'b-+', 'LineWidth', 0.7); 
plot(x, y4, 'm-o', 'LineWidth', 0.7); 
plot(x, y5, 'g-', 'Marker', 'square', 'LineWidth', 0.7);
plot(x, y6, 'b-', 'Marker', 'pentagram', 'LineWidth', 0.7);

% 设置图例和轴标签
legend('House', 'Baboon', 'Peppers', 'Airplane', 'Sailboat', 'Barbara'); % 图例
ylim([0.955, 1]);
yticks(0.955:0.005:1);
ylabel('NC');
xlabel('Density'); % x 轴标签
% grid on;  % 显示网格线
% 将四周框起来
% 设置 x 轴刻度和标签
box on
%% 平均滤波
% 定义 x 轴范围
x = linspace(0.05, 0.3, 6);
y1=[0.9988
0.9978
0.9951
0.9931
0.9907
0.9883];
y2=[0.9984
0.9964
0.9926
0.9897
0.9866
0.9839];
y3=[0.9982
0.9960
0.9917
0.9886
0.9856
0.9834];
y4=[0.9988
0.9979
0.9955
0.9937
0.9916
0.9897];
y5=[0.9984
0.9963
0.9921
0.9894
0.9864
0.9843];
y6=[0.9989
0.9975
0.9949
0.9929
0.9906
0.9884];
% 绘制折线图，使用不同的颜色和形状区分每条折线
figure;
hold on;
plot(x, y1, 'g-x', 'LineWidth', 0.7); 
plot(x, y2, 'c-^', 'LineWidth', 0.7); 
plot(x, y3, 'b-+', 'LineWidth', 0.7); 
plot(x, y4, 'm-o', 'LineWidth', 0.7); 
plot(x, y5, 'r-', 'Marker', 'square', 'LineWidth', 0.7);
plot(x, y6, 'b-', 'Marker', 'pentagram', 'LineWidth', 0.7);

% 设置图例和轴标签
legend('House', 'Baboon', 'Peppers', 'Airplane', 'Sailboat', 'Barbara'); % 图例
ylim([0.975, 1]);
yticks(0.975:0.005:1);
ylabel('NC');
xlabel('Filter Size'); % x 轴标签
% grid on;  % 显示网格线
% 将四周框起来
xticks(x);
xticklabels({'2×2', '3×3', '4×4', '5×5', '6×6', '7×7'});
box on
%% JPEG
% 定义 x 轴范围
x = linspace(10, 60, 6);
y1=[0.9910
0.9977
0.9981
0.9986
0.9989
0.9988];
y2=[0.9891
0.9959
0.9972
0.9972
0.9973
0.9974];
y3=[0.9919
0.9961
0.9960
0.9966
0.9968
0.9965];
y4=[0.9889
0.9965
0.9979
0.9986
0.9984
0.9987];
y5=[0.9921
0.9972
0.9971
0.9977
0.9975
0.9976];
y6=[0.9886
0.9973
0.9977
0.9991
0.9987
0.9987];
% 绘制折线图，使用不同的颜色和形状区分每条折线
figure;
hold on;
plot(x, y1, 'r-x', 'LineWidth', 0.7); 
plot(x, y2, 'c-^', 'LineWidth', 0.7); 
plot(x, y3, 'b-+', 'LineWidth', 0.7); 
plot(x, y4, 'm-o', 'LineWidth', 0.7); 
plot(x, y5, 'g-', 'Marker', 'square', 'LineWidth', 0.7);
plot(x, y6, 'b-', 'Marker', 'pentagram', 'LineWidth', 0.7);
% 设置图例和轴标签
legend('House', 'Baboon', 'Peppers', 'Airplane', 'Sailboat', 'Barbara'); % 图例
ylim([0.98, 1]);
yticks(0.98:0.002:1);
ylabel('NC');
xlabel('Quality Factor(QF)'); % x 轴标签
% grid on;  % 显示网格线
% 将四周框起来
% 设置 x 轴刻度和标签
box on
%% JPEG2000
% 定义 x 轴范围
x = linspace(10, 60, 6);
y1=[0.9997
0.9996
0.9994
0.9991
0.9987
0.9979];
y2=[0.9990
0.9960
0.9915
0.9897
0.9872
0.9869];
y3=[0.9992
0.9989
0.9986
0.9979
0.9974
0.9968];
y4=[0.9997
0.9995
0.9991
0.9989
0.9982
0.9971];
y5=[0.9995
0.9991
0.9986
0.9973
0.9958
0.9940];
y6=[0.9997
0.9990
0.9974
0.9969
0.9947
0.9934];
% 绘制折线图，使用不同的颜色和形状区分每条折线
figure;
hold on;
plot(x, y1, 'r-x', 'LineWidth', 0.7); 
plot(x, y2, 'c-^', 'LineWidth', 0.7); 
plot(x, y3, 'b-+', 'LineWidth', 0.7); 
plot(x, y4, 'm-o', 'LineWidth', 0.7); 
plot(x, y5, 'g-', 'Marker', 'square', 'LineWidth', 0.7);
plot(x, y6, 'b-', 'Marker', 'pentagram', 'LineWidth', 0.7);
% 设置图例和轴标签
legend('House', 'Baboon', 'Peppers', 'Airplane', 'Sailboat', 'Barbara'); % 图例
ylim([0.98, 1]);
yticks(0.98:0.002:1);
ylabel('NC');
xlabel('Compression Ratio(CR)'); % x 轴标签
% grid on;  % 显示网格线
% 将四周框起来
% 设置 x 轴刻度和标签
box on
%% 高斯滤波
% 定义 x 轴范围
x = linspace(0.05, 0.3, 6);
y1=[0.9988
0.9995
0.9987
0.9995
0.9987
0.9995];
y2=[0.9984
0.9993
0.9983
0.9993
0.9983
0.9993];
y3=[0.9982
0.9991
0.9981
0.9991
0.9981
0.9991];
y4=[0.9988
0.9995
0.9987
0.9995
0.9987
0.9995];
y5=[0.9984
0.9993
0.9982
0.9993
0.9982
0.9993];
y6=[0.9989
0.9995
0.9988
0.9995
0.9988
0.9995];
% 绘制折线图，使用不同的颜色和形状区分每条折线
figure;
hold on;
plot(x, y1, 'g-x', 'LineWidth', 0.7); 
plot(x, y2, 'c-^', 'LineWidth', 0.7); 
plot(x, y3, 'b-+', 'LineWidth', 0.7); 
plot(x, y4, 'm-o', 'LineWidth', 0.7); 
plot(x, y5, 'r-', 'Marker', 'square', 'LineWidth', 0.7);
plot(x, y6, 'b-', 'Marker', 'pentagram', 'LineWidth', 0.7);

% 设置图例和轴标签
legend('House', 'Baboon', 'Peppers', 'Airplane', 'Sailboat', 'Barbara'); % 图例
ylim([0.992, 1]);
yticks(0.992:0.001:1);
ylabel('NC');
xlabel('Filter Size'); % x 轴标签
% grid on;  % 显示网格线
% 将四周框起来
xticks(x);
xticklabels({'2×2', '3×3', '4×4', '5×5', '6×6', '7×7'});
box on
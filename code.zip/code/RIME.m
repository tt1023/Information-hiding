function [Best_alpha, Best_alpha_rate, Convergence_curve] = RIME(N, Max_iter, lb, ub, dim, fobj)
% 冰霜优化算法

% 初始化位置
Best_alpha = zeros(1, dim);
Best_alpha_rate = -inf; % 将此值更改为 -inf 以便于最大化问题
Rimepop = initialization(N, dim, ub, lb); % 初始化随机解集合
Lb = lb * ones(1, dim); % 下界
Ub = ub * ones(1, dim); % 上界
it = 1; % 迭代次数
Convergence_curve = zeros(1, Max_iter);
Rime_rates = zeros(1, N); % 初始化适应度值
newRime_rates = zeros(1, N);
W = 5; % Soft-rime 参数，参考论文中的4.3.1小节
% 计算初始位置的适应度值
for i = 1:N
    Rime_rates(1, i) = feval(fobj, Rimepop(i, :)); % 计算每个搜索体的适应度值
    % 进行贪婪选择
    if Rime_rates(1, i) > Best_alpha_rate
        Best_alpha_rate = Rime_rates(1, i);
        Best_alpha = Rimepop(i, :);
    end
end
% 主循环
while it <= Max_iter
    RimeFactor = (rand - 0.5) * 2 * cos((pi * it / (Max_iter / 10))) * (1 - round(it * W / Max_iter) / W); % Eq.(3),(4),(5) 的参数
    E = (it / Max_iter) ^ 0.5; % Eq.(6) 的参数
    newRimepop = Rimepop; % 记录新的种群
    normalized_rime_rates = normr(Rime_rates); % Eq.(7) 的参数
    for i = 1:N
        for j = 1:dim
            % Soft-rime 搜索策略
            r1 = rand();
            if r1 < E
                newRimepop(i, j) = Best_alpha(1, j) + RimeFactor * ((Ub(j) - Lb(j)) * rand + Lb(j)); % Eq.(3)
            end
            % Hard-rime 穿孔机制
            r2 = rand();
            if r2 < normalized_rime_rates(i)
                newRimepop(i, j) = Best_alpha(1, j); % Eq.(7)
            end
        end
    end
    for i = 1:N
        % 边界吸收
        Flag4ub = newRimepop(i, :) > ub;
        Flag4lb = newRimepop(i, :) < lb;
        newRimepop(i, :) = (newRimepop(i, :) .* (~(Flag4ub + Flag4lb))) + ub .* Flag4ub + lb .* Flag4lb;
        newRime_rates(1, i) = feval(fobj, newRimepop(i, :));
        % 正向贪婪选择机制
        if newRime_rates(1, i) > Rime_rates(1, i)
            Rime_rates(1, i) = newRime_rates(1, i);
            Rimepop(i, :) = newRimepop(i, :);
            
            if newRime_rates(1, i) > Best_alpha_rate
                Best_alpha_rate = newRime_rates(1, i);
                Best_alpha = Rimepop(i, :);
            end
        end
    end
    Convergence_curve(it) = Best_alpha_rate;
    it = it + 1;
    % 显示当前迭代结果
%     fprintf('Best alpha: %.4f, Best alpha_rate: %.4f\n', Best_alpha, Best_alpha_rate);
end
end
function Positions=initialization(SearchAgents_no,dim,ub,lb)
Boundary_no= size(ub,2); % numnber of boundaries
% If the boundaries of all variables are equal and user enter a signle
% number for both ub and lb
if Boundary_no==1
    Positions=rand(SearchAgents_no,dim).*(ub-lb)+lb;
end
% If each variable has a different lb and ub
if Boundary_no>1
    for i=1:dim
        ub_i=ub(i);
        lb_i=lb(i);
        Positions(:,i)=rand(SearchAgents_no,1).*(ub_i-lb_i)+lb_i;
    end
end
end



function fitness = calculate_fitness(alpha)
% Original=imread('lena.jpg');
Original=imread('house.jpg');
% Original=imread('babooncolor.tif');
% Original=imread('Pepppers.tiff');
% Original=imread('Sailboat.tiff');
% Original=imread('barbara.bmp');
% Original=imread('Airplane.tiff');
% watermark=imread('Peugeot.bmp');
watermark=imread('W4.bmp');
% watermark = imread('8color.bmp');
watermarkr=watermark(:,:,1);
watermarkg=watermark(:,:,2);
watermarkb=watermark(:,:,3);
% 读取图像
grayImager = watermarkr;
% 图像参数
[M, N] = size(grayImager);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行置乱
scrambledimager = zeros(M, N, 'like', grayImager);
for i = 1:M
    for j = 1:N
        scrambledimager(i, j) = grayImager(grayCodeMatrix(i, j) + 1);
    end
end
scrambledr = arnoldScramble(scrambledimager);

% 读取图像
grayImageg = watermarkg;
% 图像参数
[M, N] = size(grayImageg);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行置乱
scrambledimageg = zeros(M, N, 'like', grayImageg);
for i = 1:M
    for j = 1:N
        scrambledimageg(i, j) = grayImageg(grayCodeMatrix(i, j) + 1);
    end
end
scrambledg = arnoldScramble(scrambledimageg);

% 读取图像
grayImageb = watermarkb;
[M, N] = size(grayImageb);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行置乱
scrambledimageb = zeros(M, N, 'like', grayImageb);
for i = 1:M
    for j = 1:N
        scrambledimageb(i, j) = grayImageb(grayCodeMatrix(i, j) + 1);
    end
end
scrambledb = arnoldScramble(scrambledimageb);
% 进行整数小波变换的参数设置
waveletName = 'haar'; 
level = 1;
doublewatermarkr = double(scrambledr);
% scaledImage = uint8(doublewatermark * 255);
[c, s] = wavedec2(doublewatermarkr, level, waveletName);
LLw = appcoef2(c, s, waveletName, level); % 低频近似系数
[LHw, HLw, HHw] = detcoef2('all', c, s, level); % 水平、垂直、对角线细节系数
doublewatermark = double(LLw);
% scaledImage = uint8(doublewatermark * 255);
% 执行整数小波变换
[c, l] = wavedec2(doublewatermark, level, waveletName);
% 提取各个频带的系数
LLw2 = appcoef2(c, l, waveletName, level); % 低频近似系数
[LHw2, HLw2, HHw2] = detcoef2('all', c, l, level); % 水平、垂直、对角线细节系数

% 进行整数小波变换的参数设置
waveletName = 'haar'; 
level = 1; 
doublewatermarkg = double(scrambledg);
% scaledImage = uint8(doublewatermark * 255);
[c, sg] = wavedec2(doublewatermarkg, level, waveletName);
% 提取各个频带的系数
LLwg = appcoef2(c, sg, waveletName, level); 
[LHwg, HLwg, HHwg] = detcoef2('all', c, sg, level); 
doublewatermarkg = double(LLwg);
% scaledImage = uint8(doublewatermark * 255);
% 执行整数小波变换
[c, lg] = wavedec2(doublewatermarkg, level, waveletName);
% 提取各个频带的系数
LLw2g = appcoef2(c, lg, waveletName, level); % 低频近似系数
[LHw2g, HLw2g, HHw2g] = detcoef2('all', c, lg, level); % 水平、垂直、对角线细节系数

% 进行整数小波变换的参数设置
waveletName = 'haar'; 
level = 1; 
doublewatermarkb = double(scrambledb);
% scaledImage = uint8(doublewatermark * 255);
[c, sb] = wavedec2(doublewatermarkb, level, waveletName);
% 提取各个频带的系数
LLwb = appcoef2(c, sb, waveletName, level); % 低频近似系数
[LHwb, HLwb, HHwb] = detcoef2('all', c, sb, level); % 水平、垂直、对角线细节系数
doublewatermarkb = double(LLwb);
% scaledImage = uint8(doublewatermark * 255);
% 执行整数小波变换
[c, lb] = wavedec2(doublewatermarkb, level, waveletName);
% 提取各个频带的系数
LLw2b = appcoef2(c, lb, waveletName, level); % 低频近似系数
[LHw2b, HLw2b, HHw2b] = detcoef2('all', c, lb, level); % 水平、垂直、对角线细节系数
%% Original image
ycbcr_image = rgb2ycbcr(Original); % 将RGB彩色图像转换为YCbCr颜色空间  
% 提取 Y 通道
Y = ycbcr_image(:,:,1);
Cb = ycbcr_image(:,:,2);
Cr = ycbcr_image(:,:,3);

% 进行整数小波变换的参数设置
waveletName = 'haar'; 
level = 1; 
doubleImage = double(Y);
% scaledImage = uint8(doubleImage * 255);
[c, s1] = wavedec2(doubleImage, level, waveletName);
% 提取各个频带的系数
cA = appcoef2(c, s1, waveletName, level); 
[cH, cV, cD] = detcoef2('all', c, s1, level); 
doubleImage = double(cA);
% scaledImage = uint8(doubleImage * 255);
[c, s2] = wavedec2(doubleImage, level, waveletName);
% 提取各个频带的系数
cA2 = appcoef2(c, s2, waveletName, level);
[cH2, cV2, cD2] = detcoef2('all', c, s2, level); 
doubleImage = double(cA2);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s3] = wavedec2(doubleImage, level, waveletName);
% 提取各个频带的系数
cA3 = appcoef2(c, s3, waveletName, level); 
[cH3, cV3, cD3] = detcoef2('all', c, s3, level);

% 进行整数小波变换的参数设置
waveletName = 'haar'; 
level = 1; 
doubleImagecb = double(Cb);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s1cb] = wavedec2(doubleImagecb, level, waveletName);
% 提取各个频带的系数
cAcb = appcoef2(c, s1cb, waveletName, level); % 低频近似系数
[cHcb, cVcb, cDcb] = detcoef2('all', c, s1cb, level); % 水平、垂直、对角线细节系数
doubleImagecb = double(cAcb);
% 执行整数小波变换
[c, s2cb] = wavedec2(doubleImagecb, level, waveletName);
% 提取各个频带的系数
cA2cb = appcoef2(c, s2cb, waveletName, level); 
[cH2cb, cV2cb, cD2cb] = detcoef2('all', c, s2cb, level);
doubleImagecb = double(cA2cb);
% scaledImage = uint8(doubleImage * 255);
[c, s3cb] = wavedec2(doubleImagecb, level, waveletName);
% 提取各个频带的系数
cA3cb = appcoef2(c, s3cb, waveletName, level); 
[cH3cb, cV3cb, cD3cb] = detcoef2('all', c, s3cb, level);

% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
doubleImagecr = double(Cr);
% scaledImage = uint8(doubleImage * 255);
[c, s1cr] = wavedec2(doubleImagecr, level, waveletName);
cAcr = appcoef2(c, s1cr, waveletName, level); % 低频近似系数
[cHcr, cVcr, cDcr] = detcoef2('all', c, s1cr, level); % 水平、垂直、对角线细节系数
doubleImagecr = double(cAcr);
% scaledImage = uint8(doubleImage * 255);
[c, s2cr] = wavedec2(doubleImagecr, level, waveletName);
cA2cr = appcoef2(c, s2cr, waveletName, level); % 低频近似系数
[cH2cr, cV2cr, cD2cr] = detcoef2('all', c, s2cr, level); % 水平、垂直、对角线细节系数
doubleImagecr = double(cA2cr);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s3cr] = wavedec2(doubleImagecr, level, waveletName);
% 提取各个频带的系数
cA3cr = appcoef2(c, s3cr, waveletName, level); % 低频近似系数
[HAwatermarkedImage, cV3cr, cD3cr] = detcoef2('all', c, s3cr, level); % 水平、垂直、对角线细节系数
%% 嵌入低频子带
grayImg = cA3;
% grayImg2 = cD3;
grayWatermark = LLw2;
H = hadamard(64);
inverseH = H' / 64;
% 对图像进行SVD分解
[U, S, V] = svd(grayImg);
% 对S进行哈达玛变换
Sh = H * S;
hw = H * grayWatermark;
% 嵌入水印图像
% for alpha = 0.01: 0.005 : 0.2
% alpha = 0.06;
% alpha = 0.155; % 水印强度调整参数
Sh_watermarked = Sh + alpha * hw;
%逆哈达玛
Sh_wa = inverseH * Sh_watermarked;
% Sh_wa2 = inverseH * Sh_watermarked2;
[Uw,Sw,Vw] = svd(Sh_wa); %Uw,Vw作为密钥保存
% [Uw2,Sw2,Vw2] = svd(Sh_wa2); %Uw,Vw作为密钥保存
% 嵌入水印后的图像逆SVD
reconstructedImg = U * Sw * V';
% reconstructedImg2 = U2 * Sw2 * V2';
embedded_block3 = waverec2([reconstructedImg, cH3, cV3, cD3], s3, waveletName);
embedded_block2 = waverec2([embedded_block3 , cH2, cV2, cD2], s2, waveletName);
embedded_block = waverec2([embedded_block2, cH, cV, cD], s1, waveletName);
% figure
% imshow(embedded_block)
ycbcr_image(:,:,1) = embedded_block;

grayImgcb = cA3cb;
% grayImg2 = cD3;
grayWatermarkg = LLw2g;
% 对图像进行SVD分解
[Ucb, Scb, Vcb] = svd(grayImgcb);
% [U2, S2, V2] = svd(grayImg2);
% 对S进行哈达玛变换
Shcb = H * Scb;
% Sh2 = H * S2;
hwg = H * grayWatermarkg;
% grayWatermark = double(grayWatermark) / 255;
% 嵌入水印图像
% alpha = 0.1; % 水印强度调整参数
Sh_watermarkedcb = Shcb + alpha * hwg;
% Sh_watermarked2 = Sh2 + alpha * hw;
%逆哈达玛
Sh_wacb = inverseH * Sh_watermarkedcb;
% Sh_wa2 = inverseH * Sh_watermarked2;
[Uwcb,Swcb,Vwcb] = svd(Sh_wacb); %Uw,Vw作为密钥保存
% [Uw2,Sw2,Vw2] = svd(Sh_wa2); %Uw,Vw作为密钥保存
% 嵌入水印后的图像逆SVD
reconstructedImgcb = Ucb * Swcb * Vcb';

% reconstructedImg2 = U2 * Sw2 * V2';
embedded_block3cb = waverec2([reconstructedImgcb, cH3cb, cV3cb, cD3cb], s3cb, waveletName);
embedded_block2cb = waverec2([embedded_block3cb , cH2cb, cV2cb, cD2cb], s2cb, waveletName);
embedded_blockcb = waverec2([embedded_block2cb, cHcb, cVcb, cDcb], s1cb, waveletName);
% 创建YCbCr图像
ycbcr_image(:,:,2) = embedded_blockcb;

grayImgcr = cA3cr;
% grayImg2 = cD3;
grayWatermarkb = LLw2b;
% 对图像进行SVD分解
[Ucr, Scr, Vcr] = svd(grayImgcr);
% [U2, S2, V2] = svd(grayImg2);
% 对S进行哈达玛变换
Shcr = H * Scr;
% Sh2 = H * S2;
hwb = H * grayWatermarkb;
% grayWatermark = double(grayWatermark) / 255;
% 嵌入水印图像
% alpha = 0.1; % 水印强度调整参数
Sh_watermarkedcr = Shcr + alpha * hwb;
% Sh_watermarked2 = Sh2 + alpha * hw;
%逆哈达玛
Sh_wacr = inverseH * Sh_watermarkedcr;
% Sh_wa2 = inverseH * Sh_watermarked2;
[Uwcr,Swcr,Vwcr] = svd(Sh_wacr); %Uw,Vw作为密钥保存
% [Uw2,Sw2,Vw2] = svd(Sh_wa2); %Uw,Vw作为密钥保存
% 嵌入水印后的图像逆SVD
reconstructedImgcr = Ucr * Swcr * Vcr';
% reconstructedImg2 = U2 * Sw2 * V2';

embedded_block3cr = waverec2([reconstructedImgcr, HAwatermarkedImage, cV3cr, cD3cr], s3cr, waveletName);
embedded_block2cr = waverec2([embedded_block3cr , cH2cr, cV2cr, cD2cr], s2cr, waveletName);
embedded_blockcr = waverec2([embedded_block2cr, cHcr, cVcr, cDcr], s1cr, waveletName);
% 创建YCbCr图像
ycbcr_image(:,:,3) = embedded_blockcr;
watermarkedImage = ycbcr2rgb(ycbcr_image);

% figure
% imshow(watermarkedImage);title('Image Converted to RGB');
% imwrite(watermarkedImage,'shuiyintu.jpg')
% Results
% figure
% subplot(2,2,1),imshow(Original),title('Original image');
% subplot(2,2,2),imshow(watermark),title('watermark image');
% subplot(2,2,3),imshow(RGB2),title('watermarked image');

% 计算 PSNR 值
psnrval= psnr(watermarkedImage, Original);
% disp(num2str(psnrval));
% disp(['The PSNR value is ', num2str(psnrval,'%.4f')]);

% 计算SSIM值
ssimValue = ssim(watermarkedImage, Original);
% disp(['嵌入水印图像的SSIM值为：', num2str(ssimValue,'%.4f')]);
%%
rChannel = watermarkedImage(:,:,1);
gChannel = watermarkedImage(:,:,2);
bChannel = watermarkedImage(:,:,3);
rMedian = medfilt2(rChannel, [3 3]);
gMedian = medfilt2(gChannel, [3 3]);
bMedian = medfilt2(bChannel, [3 3]);
% rMedian = medfilt2(rChannel, [5 5]);
% gMedian = medfilt2(gChannel, [5 5]);
% bMedian = medfilt2(bChannel, [5 5]);
attackimage1 = cat(3, rMedian, gMedian, bMedian);
% 应用平均过滤器,定义平均过滤器
filter = fspecial('average', 3);
attackimage2 = imfilter(watermarkedImage, filter);
% 对图像进行滤波,生成3x3高斯低通滤波器
h = fspecial('gaussian', 3);
attackimage3 = imfilter(watermarkedImage, h);
% 应用椒盐噪声攻击
attackimage4 = imnoise(watermarkedImage, 'salt & pepper', 0.01);
% 添加高斯噪声到水印图像
attackimage5= imnoise(watermarkedImage, 'gaussian', 0, 0.01);
% 添加Speckle噪声
attackimage6 = imnoise(watermarkedImage, 'speckle', 0.01);

recoveredYCbCr = rgb2ycbcr(attackimage1);
recoveredY = recoveredYCbCr(:,:,1);
recoveredCb = recoveredYCbCr(:,:,2);
recoveredCr = recoveredYCbCr(:,:,3);
% 进行整数小波变换的参数设置
wavelet = 'haar'; 
level = 1; 
doubleWImage = double(recoveredY);
% scaledWImage = uint8(doubleWImage * 255);
[c, s1] = wavedec2(doubleWImage, level, wavelet);
cAw = appcoef2(c, s1, wavelet, level); % 低频近似系数
[cHw, cVw, cDw] = detcoef2('all', c, s1, level); % 水平、垂直、对角线细节系数
doubleWImage = double(cAw);
% scaledWImage = uint8(doubleWImage * 255);
[c, s2] = wavedec2(doubleWImage, level, wavelet);
cAw2 = appcoef2(c, s2, wavelet, level); % 低频近似系数
[cHw2, cVw2, cDw2] = detcoef2('all', c, s2, level); % 水平、垂直、对角线细节系数
doubleWImage = double(cAw2);
% scaledWImage = uint8(doubleWImage * 255);
[c, s3] = wavedec2(doubleWImage, level, wavelet);
% 提取各个频带的系数
cAw3 = appcoef2(c, s3, wavelet, level); % 低频近似系数
[cHw3, cVw3, cDw3] = detcoef2('all', c, s3, level); % 水平、垂直、对角线细节系数
%提取水印
[Uwex,Swex,Vwex] = svd(cAw3);
Swe = Uw * Swex * Vw';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Sh)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2 = waverec2([Wex, LHw2, HLw2, HHw2], l, wavelet);
reconstructedImage = waverec2([reconstructedImage2, LHw, HLw, HHw], s, wavelet);
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = U * Shor * V';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cHw3, cVw3, cDw3], s3, waveletName);
or_block2 = waverec2([or_block3, cHw2, cVw2, cDw2], s2, waveletName);
or_block = waverec2([or_block2, cHw, cVw, cDw], s1, waveletName);
% recoveredY((maxRowIndex-1)*blockSize+1:maxRowIndex*blockSize, (maxColIndex-1)*blockSize+1:maxColIndex*blockSize) = or_block;
% figure
% imshow(recoveredY);
recoveredYCbCr(:,:,1) = or_block ;

% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecbw = double(recoveredCb);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s1cbw] = wavedec2(doubleImagecbw, level, waveletName);
% 提取各个频带的系数
cAcbw = appcoef2(c, s1cbw, waveletName, level); % 低频近似系数
[cHcbw, cVcbw, cDcbw] = detcoef2('all', c, s1cbw, level); % 水平、垂直、对角线细节系数
doubleImagecbw = double(cAcbw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s2cbw] = wavedec2(doubleImagecbw, level, waveletName);
% 提取各个频带的系数
cA2cbw = appcoef2(c, s2cbw, waveletName, level); % 低频近似系数
[cH2cbw, cV2cbw, cD2cbw] = detcoef2('all', c, s2cbw, level); % 水平、垂直、对角线细节系数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecbw = double(cA2cbw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s3cbw] = wavedec2(doubleImagecbw, level, waveletName);
% 提取各个频带的系数
cA3cbw = appcoef2(c, s3cbw, waveletName, level); % 低频近似系数
[cH3cbw, cV3cbw, cD3cbw] = detcoef2('all', c, s3cbw, level); % 水平、垂直、对角线细节系数

%提取水印
[Uwex,Swex,Vwex] = svd(cA3cbw);
Swe = Uwcb * Swex * Vwcb';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Shcb)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2g = waverec2([Wex, LHw2g, HLw2g, HHw2g], lg, wavelet);
reconstructedImageg = waverec2([reconstructedImage2g, LHwg, HLwg, HHwg], sg, wavelet);
% figure
% imshow(reconstructedImage)
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = Ucb * Shor * Vcb';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cH3cbw, cV3cbw, cD3cbw], s3cbw, waveletName);
or_block2 = waverec2([or_block3, cH2cbw, cV2cbw, cD2cbw], s2cbw, waveletName);
or_block = waverec2([or_block2, cHcbw, cVcbw, cDcbw], s1cbw, waveletName);
% recoveredY((maxRowIndex-1)*blockSize+1:maxRowIndex*blockSize, (maxColIndex-1)*blockSize+1:maxColIndex*blockSize) = or_block;
% figure
% imshow(recoveredY);
recoveredYCbCr(:,:,2) = or_block ;


% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecrw = double(recoveredCr);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s1crw] = wavedec2(doubleImagecrw, level, waveletName);
% 提取各个频带的系数
cAcrw = appcoef2(c, s1crw, waveletName, level); % 低频近似系数
[cHcrw, cVcrw, cDcrw] = detcoef2('all', c, s1crw, level); % 水平、垂直、对角线细节系数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecrw = double(cAcrw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s2crw] = wavedec2(doubleImagecrw, level, waveletName);
% 提取各个频带的系数
cA2crw = appcoef2(c, s2crw, waveletName, level); % 低频近似系数
[cH2crw, cV2crw, cD2crw] = detcoef2('all', c, s2crw, level); % 水平、垂直、对角线细节系数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecrw = double(cA2crw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s3crw] = wavedec2(doubleImagecrw, level, waveletName);
% 提取各个频带的系数
cA3crw = appcoef2(c, s3crw, waveletName, level); % 低频近似系数
[cH3crw, cV3crw, cD3crw] = detcoef2('all', c, s3crw, level); % 水平、垂直、对角线细节系数

%提取水印
[Uwex,Swex,Vwex] = svd(cA3crw);
Swe = Uwcr * Swex * Vwcr';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Shcr)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2b = waverec2([Wex, LHw2b, HLw2b, HHw2b], lb, wavelet);
reconstructedImageb = waverec2([reconstructedImage2b, LHwb, HLwb, HHwb], sb, wavelet);
% figure
% imshow(reconstructedImage)
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = Ucr * Shor * Vcr';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cH3crw, cV3crw, cD3crw], s3crw, waveletName);
or_block2 = waverec2([or_block3, cH2crw, cV2crw, cD2crw], s2crw, waveletName);
or_block = waverec2([or_block2, cHcrw, cVcrw, cDcrw], s1crw, waveletName);
% recoveredY((maxRowIndex-1)*blockSize+1:maxRowIndex*blockSize, (maxColIndex-1)*blockSize+1:maxColIndex*blockSize) = or_block;
% figure
% imshow(recoveredY);
recoveredYCbCr(:,:,3) = or_block ;
originalImage = ycbcr2rgb(recoveredYCbCr);
% figure
% imshow(originalImage);title('恢复的原始图像');
% 计算 PSNR 值
% psnrval= psnr(originalImage, Original);
% disp(['The PSNR value is ', num2str(psnrval,'%.4f')]);
% % 计算SSIM值
% ssimValue = ssim(originalImage, Original);
% disp(['嵌入水印图像的SSIM值为：', num2str(ssimValue,'%.4f')]);

% 将水印图像还原
unscrambled_w = arnoldUnscramble(reconstructedImage);
unscrambled_wg = arnoldUnscramble(reconstructedImageg);
unscrambled_wb = arnoldUnscramble(reconstructedImageb);

% 读取置乱后的图像
scrambledImager = unscrambled_w;
% 图像参数
[M, N] = size(scrambledImager);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImager = zeros(M, N, 'like', scrambledImager);
for i = 1:M
    for j = 1:N
        recoveredImager(grayCodeMatrix(i, j) + 1) = scrambledImager(i, j);
    end
end

% 读取置乱后的图像
scrambledImageg = unscrambled_wg;
% 图像参数
[M, N] = size(scrambledImageg);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImageg = zeros(M, N, 'like', scrambledImageg);
for i = 1:M
    for j = 1:N
        recoveredImageg(grayCodeMatrix(i, j) + 1) = scrambledImageg(i, j);
    end
end

% 读取置乱后的图像
scrambledImageb = unscrambled_wb;
% 图像参数
[M, N] = size(scrambledImageb);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImageb = zeros(M, N, 'like', scrambledImageb);
for i = 1:M
    for j = 1:N
        recoveredImageb(grayCodeMatrix(i, j) + 1) = scrambledImageb(i, j);
    end
end

recoveredImage = uint8(cat(3,recoveredImager,recoveredImageg,recoveredImageb));
% 显示置乱后的图像和恢复后的图像
% figure;
% imshow(recoveredImage,[]), title('恢复后的图像');

% 计算提取水印和原始水印的标准差
std_extracted = std(double(recoveredImage(:)));
std_original = std(double(watermark(:)));
% 计算提取水印和原始水印的协方差矩阵
cov_matrix = cov(double(recoveredImage(:)), double(watermark(:)));
% 计算归一化相关系数（NC）值
NC1 = cov_matrix(1, 2) / (std_extracted * std_original);
%%
recoveredYCbCr = rgb2ycbcr(attackimage2);
recoveredY = recoveredYCbCr(:,:,1);
recoveredCb = recoveredYCbCr(:,:,2);
recoveredCr = recoveredYCbCr(:,:,3);
% 进行整数小波变换的参数设置
wavelet = 'haar'; 
level = 1; 
doubleWImage = double(recoveredY);
% scaledWImage = uint8(doubleWImage * 255);
[c, s1] = wavedec2(doubleWImage, level, wavelet);
cAw = appcoef2(c, s1, wavelet, level); % 低频近似系数
[cHw, cVw, cDw] = detcoef2('all', c, s1, level); % 水平、垂直、对角线细节系数
doubleWImage = double(cAw);
% scaledWImage = uint8(doubleWImage * 255);
[c, s2] = wavedec2(doubleWImage, level, wavelet);
cAw2 = appcoef2(c, s2, wavelet, level); % 低频近似系数
[cHw2, cVw2, cDw2] = detcoef2('all', c, s2, level); % 水平、垂直、对角线细节系数
doubleWImage = double(cAw2);
% scaledWImage = uint8(doubleWImage * 255);
[c, s3] = wavedec2(doubleWImage, level, wavelet);
% 提取各个频带的系数
cAw3 = appcoef2(c, s3, wavelet, level); % 低频近似系数
[cHw3, cVw3, cDw3] = detcoef2('all', c, s3, level); % 水平、垂直、对角线细节系数
%提取水印
[Uwex,Swex,Vwex] = svd(cAw3);
Swe = Uw * Swex * Vw';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Sh)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2 = waverec2([Wex, LHw2, HLw2, HHw2], l, wavelet);
reconstructedImage = waverec2([reconstructedImage2, LHw, HLw, HHw], s, wavelet);
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = U * Shor * V';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cHw3, cVw3, cDw3], s3, waveletName);
or_block2 = waverec2([or_block3, cHw2, cVw2, cDw2], s2, waveletName);
or_block = waverec2([or_block2, cHw, cVw, cDw], s1, waveletName);
% recoveredY((maxRowIndex-1)*blockSize+1:maxRowIndex*blockSize, (maxColIndex-1)*blockSize+1:maxColIndex*blockSize) = or_block;
% figure
% imshow(recoveredY);
recoveredYCbCr(:,:,1) = or_block ;

% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecbw = double(recoveredCb);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s1cbw] = wavedec2(doubleImagecbw, level, waveletName);
% 提取各个频带的系数
cAcbw = appcoef2(c, s1cbw, waveletName, level); % 低频近似系数
[cHcbw, cVcbw, cDcbw] = detcoef2('all', c, s1cbw, level); % 水平、垂直、对角线细节系数
% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecbw = double(cAcbw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s2cbw] = wavedec2(doubleImagecbw, level, waveletName);
% 提取各个频带的系数
cA2cbw = appcoef2(c, s2cbw, waveletName, level); % 低频近似系数
[cH2cbw, cV2cbw, cD2cbw] = detcoef2('all', c, s2cbw, level); % 水平、垂直、对角线细节系数
% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecbw = double(cA2cbw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s3cbw] = wavedec2(doubleImagecbw, level, waveletName);
% 提取各个频带的系数
cA3cbw = appcoef2(c, s3cbw, waveletName, level); % 低频近似系数
[cH3cbw, cV3cbw, cD3cbw] = detcoef2('all', c, s3cbw, level); % 水平、垂直、对角线细节系数

%提取水印
[Uwex,Swex,Vwex] = svd(cA3cbw);
Swe = Uwcb * Swex * Vwcb';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Shcb)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2g = waverec2([Wex, LHw2g, HLw2g, HHw2g], lg, wavelet);
reconstructedImageg = waverec2([reconstructedImage2g, LHwg, HLwg, HHwg], sg, wavelet);
% figure
% imshow(reconstructedImage)
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = Ucb * Shor * Vcb';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cH3cbw, cV3cbw, cD3cbw], s3cbw, waveletName);
or_block2 = waverec2([or_block3, cH2cbw, cV2cbw, cD2cbw], s2cbw, waveletName);
or_block = waverec2([or_block2, cHcbw, cVcbw, cDcbw], s1cbw, waveletName);
% recoveredY((maxRowIndex-1)*blockSize+1:maxRowIndex*blockSize, (maxColIndex-1)*blockSize+1:maxColIndex*blockSize) = or_block;
% figure
% imshow(recoveredY);
recoveredYCbCr(:,:,2) = or_block ;


% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecrw = double(recoveredCr);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s1crw] = wavedec2(doubleImagecrw, level, waveletName);
% 提取各个频带的系数
cAcrw = appcoef2(c, s1crw, waveletName, level); % 低频近似系数
[cHcrw, cVcrw, cDcrw] = detcoef2('all', c, s1crw, level); % 水平、垂直、对角线细节系数
% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecrw = double(cAcrw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s2crw] = wavedec2(doubleImagecrw, level, waveletName);
% 提取各个频带的系数
cA2crw = appcoef2(c, s2crw, waveletName, level); % 低频近似系数
[cH2crw, cV2crw, cD2crw] = detcoef2('all', c, s2crw, level); % 水平、垂直、对角线细节系数
% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecrw = double(cA2crw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s3crw] = wavedec2(doubleImagecrw, level, waveletName);
% 提取各个频带的系数
cA3crw = appcoef2(c, s3crw, waveletName, level); % 低频近似系数
[cH3crw, cV3crw, cD3crw] = detcoef2('all', c, s3crw, level); % 水平、垂直、对角线细节系数

%提取水印
[Uwex,Swex,Vwex] = svd(cA3crw);
Swe = Uwcr * Swex * Vwcr';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Shcr)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2b = waverec2([Wex, LHw2b, HLw2b, HHw2b], lb, wavelet);
reconstructedImageb = waverec2([reconstructedImage2b, LHwb, HLwb, HHwb], sb, wavelet);
% figure
% imshow(reconstructedImage)
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = Ucr * Shor * Vcr';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cH3crw, cV3crw, cD3crw], s3crw, waveletName);
or_block2 = waverec2([or_block3, cH2crw, cV2crw, cD2crw], s2crw, waveletName);
or_block = waverec2([or_block2, cHcrw, cVcrw, cDcrw], s1crw, waveletName);
% recoveredY((maxRowIndex-1)*blockSize+1:maxRowIndex*blockSize, (maxColIndex-1)*blockSize+1:maxColIndex*blockSize) = or_block;
% figure
% imshow(recoveredY);
recoveredYCbCr(:,:,3) = or_block ;
originalImage = ycbcr2rgb(recoveredYCbCr);
% figure
% imshow(originalImage);title('恢复的原始图像');
% 计算 PSNR 值
% psnrval= psnr(originalImage, Original);
% disp(['The PSNR value is ', num2str(psnrval,'%.4f')]);
% % 计算SSIM值
% ssimValue = ssim(originalImage, Original);
% disp(['嵌入水印图像的SSIM值为：', num2str(ssimValue,'%.4f')]);

% 将水印图像还原
unscrambled_w = arnoldUnscramble(reconstructedImage);
unscrambled_wg = arnoldUnscramble(reconstructedImageg);
unscrambled_wb = arnoldUnscramble(reconstructedImageb);

% 读取置乱后的图像
scrambledImager = unscrambled_w;
% 图像参数
[M, N] = size(scrambledImager);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImager = zeros(M, N, 'like', scrambledImager);
for i = 1:M
    for j = 1:N
        recoveredImager(grayCodeMatrix(i, j) + 1) = scrambledImager(i, j);
    end
end

% 读取置乱后的图像
scrambledImageg = unscrambled_wg;
% 图像参数
[M, N] = size(scrambledImageg);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImageg = zeros(M, N, 'like', scrambledImageg);
for i = 1:M
    for j = 1:N
        recoveredImageg(grayCodeMatrix(i, j) + 1) = scrambledImageg(i, j);
    end
end

% 读取置乱后的图像
scrambledImageb = unscrambled_wb;
% 图像参数
[M, N] = size(scrambledImageb);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImageb = zeros(M, N, 'like', scrambledImageb);
for i = 1:M
    for j = 1:N
        recoveredImageb(grayCodeMatrix(i, j) + 1) = scrambledImageb(i, j);
    end
end

recoveredImage = uint8(cat(3,recoveredImager,recoveredImageg,recoveredImageb));
% 显示置乱后的图像和恢复后的图像
% figure;
% imshow(recoveredImage,[]), title('恢复后的图像');

% 计算提取水印和原始水印的标准差
std_extracted = std(double(recoveredImage(:)));
std_original = std(double(watermark(:)));
% 计算提取水印和原始水印的协方差矩阵
cov_matrix = cov(double(recoveredImage(:)), double(watermark(:)));
% 计算归一化相关系数（NC）值
NC2 = cov_matrix(1, 2) / (std_extracted * std_original);
%%
recoveredYCbCr = rgb2ycbcr(attackimage3);
recoveredY = recoveredYCbCr(:,:,1);
recoveredCb = recoveredYCbCr(:,:,2);
recoveredCr = recoveredYCbCr(:,:,3);
% 进行整数小波变换的参数设置
wavelet = 'haar'; 
level = 1; 
doubleWImage = double(recoveredY);
% scaledWImage = uint8(doubleWImage * 255);
[c, s1] = wavedec2(doubleWImage, level, wavelet);
cAw = appcoef2(c, s1, wavelet, level); % 低频近似系数
[cHw, cVw, cDw] = detcoef2('all', c, s1, level); % 水平、垂直、对角线细节系数
doubleWImage = double(cAw);
% scaledWImage = uint8(doubleWImage * 255);
[c, s2] = wavedec2(doubleWImage, level, wavelet);
cAw2 = appcoef2(c, s2, wavelet, level); % 低频近似系数
[cHw2, cVw2, cDw2] = detcoef2('all', c, s2, level); % 水平、垂直、对角线细节系数
doubleWImage = double(cAw2);
% scaledWImage = uint8(doubleWImage * 255);
[c, s3] = wavedec2(doubleWImage, level, wavelet);
% 提取各个频带的系数
cAw3 = appcoef2(c, s3, wavelet, level); % 低频近似系数
[cHw3, cVw3, cDw3] = detcoef2('all', c, s3, level); % 水平、垂直、对角线细节系数
%提取水印
[Uwex,Swex,Vwex] = svd(cAw3);
Swe = Uw * Swex * Vw';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Sh)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2 = waverec2([Wex, LHw2, HLw2, HHw2], l, wavelet);
reconstructedImage = waverec2([reconstructedImage2, LHw, HLw, HHw], s, wavelet);
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = U * Shor * V';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cHw3, cVw3, cDw3], s3, waveletName);
or_block2 = waverec2([or_block3, cHw2, cVw2, cDw2], s2, waveletName);
or_block = waverec2([or_block2, cHw, cVw, cDw], s1, waveletName);
% recoveredY((maxRowIndex-1)*blockSize+1:maxRowIndex*blockSize, (maxColIndex-1)*blockSize+1:maxColIndex*blockSize) = or_block;
% figure
% imshow(recoveredY);
recoveredYCbCr(:,:,1) = or_block ;

% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecbw = double(recoveredCb);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s1cbw] = wavedec2(doubleImagecbw, level, waveletName);
% 提取各个频带的系数
cAcbw = appcoef2(c, s1cbw, waveletName, level); % 低频近似系数
[cHcbw, cVcbw, cDcbw] = detcoef2('all', c, s1cbw, level); % 水平、垂直、对角线细节系数
% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecbw = double(cAcbw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s2cbw] = wavedec2(doubleImagecbw, level, waveletName);
% 提取各个频带的系数
cA2cbw = appcoef2(c, s2cbw, waveletName, level); % 低频近似系数
[cH2cbw, cV2cbw, cD2cbw] = detcoef2('all', c, s2cbw, level); % 水平、垂直、对角线细节系数
% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecbw = double(cA2cbw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s3cbw] = wavedec2(doubleImagecbw, level, waveletName);
% 提取各个频带的系数
cA3cbw = appcoef2(c, s3cbw, waveletName, level); % 低频近似系数
[cH3cbw, cV3cbw, cD3cbw] = detcoef2('all', c, s3cbw, level); % 水平、垂直、对角线细节系数

%提取水印
[Uwex,Swex,Vwex] = svd(cA3cbw);
Swe = Uwcb * Swex * Vwcb';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Shcb)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2g = waverec2([Wex, LHw2g, HLw2g, HHw2g], lg, wavelet);
reconstructedImageg = waverec2([reconstructedImage2g, LHwg, HLwg, HHwg], sg, wavelet);
% figure
% imshow(reconstructedImage)
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = Ucb * Shor * Vcb';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cH3cbw, cV3cbw, cD3cbw], s3cbw, waveletName);
or_block2 = waverec2([or_block3, cH2cbw, cV2cbw, cD2cbw], s2cbw, waveletName);
or_block = waverec2([or_block2, cHcbw, cVcbw, cDcbw], s1cbw, waveletName);
% recoveredY((maxRowIndex-1)*blockSize+1:maxRowIndex*blockSize, (maxColIndex-1)*blockSize+1:maxColIndex*blockSize) = or_block;
% figure
% imshow(recoveredY);
recoveredYCbCr(:,:,2) = or_block ;


% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecrw = double(recoveredCr);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s1crw] = wavedec2(doubleImagecrw, level, waveletName);
% 提取各个频带的系数
cAcrw = appcoef2(c, s1crw, waveletName, level); % 低频近似系数
[cHcrw, cVcrw, cDcrw] = detcoef2('all', c, s1crw, level); % 水平、垂直、对角线细节系数
% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecrw = double(cAcrw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s2crw] = wavedec2(doubleImagecrw, level, waveletName);
% 提取各个频带的系数
cA2crw = appcoef2(c, s2crw, waveletName, level); % 低频近似系数
[cH2crw, cV2crw, cD2crw] = detcoef2('all', c, s2crw, level); % 水平、垂直、对角线细节系数
% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecrw = double(cA2crw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s3crw] = wavedec2(doubleImagecrw, level, waveletName);
% 提取各个频带的系数
cA3crw = appcoef2(c, s3crw, waveletName, level); % 低频近似系数
[cH3crw, cV3crw, cD3crw] = detcoef2('all', c, s3crw, level); % 水平、垂直、对角线细节系数

%提取水印
[Uwex,Swex,Vwex] = svd(cA3crw);
Swe = Uwcr * Swex * Vwcr';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Shcr)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2b = waverec2([Wex, LHw2b, HLw2b, HHw2b], lb, wavelet);
reconstructedImageb = waverec2([reconstructedImage2b, LHwb, HLwb, HHwb], sb, wavelet);
% figure
% imshow(reconstructedImage)
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = Ucr * Shor * Vcr';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cH3crw, cV3crw, cD3crw], s3crw, waveletName);
or_block2 = waverec2([or_block3, cH2crw, cV2crw, cD2crw], s2crw, waveletName);
or_block = waverec2([or_block2, cHcrw, cVcrw, cDcrw], s1crw, waveletName);
% recoveredY((maxRowIndex-1)*blockSize+1:maxRowIndex*blockSize, (maxColIndex-1)*blockSize+1:maxColIndex*blockSize) = or_block;
% figure
% imshow(recoveredY);
recoveredYCbCr(:,:,3) = or_block ;
originalImage = ycbcr2rgb(recoveredYCbCr);
% figure
% imshow(originalImage);title('恢复的原始图像');
% 计算 PSNR 值
% psnrval= psnr(originalImage, Original);
% disp(['The PSNR value is ', num2str(psnrval,'%.4f')]);
% % 计算SSIM值
% ssimValue = ssim(originalImage, Original);
% disp(['嵌入水印图像的SSIM值为：', num2str(ssimValue,'%.4f')]);

% 将水印图像还原
unscrambled_w = arnoldUnscramble(reconstructedImage);
unscrambled_wg = arnoldUnscramble(reconstructedImageg);
unscrambled_wb = arnoldUnscramble(reconstructedImageb);

% 读取置乱后的图像
scrambledImager = unscrambled_w;
% 图像参数
[M, N] = size(scrambledImager);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImager = zeros(M, N, 'like', scrambledImager);
for i = 1:M
    for j = 1:N
        recoveredImager(grayCodeMatrix(i, j) + 1) = scrambledImager(i, j);
    end
end

% 读取置乱后的图像
scrambledImageg = unscrambled_wg;
% 图像参数
[M, N] = size(scrambledImageg);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImageg = zeros(M, N, 'like', scrambledImageg);
for i = 1:M
    for j = 1:N
        recoveredImageg(grayCodeMatrix(i, j) + 1) = scrambledImageg(i, j);
    end
end

% 读取置乱后的图像
scrambledImageb = unscrambled_wb;
% 图像参数
[M, N] = size(scrambledImageb);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImageb = zeros(M, N, 'like', scrambledImageb);
for i = 1:M
    for j = 1:N
        recoveredImageb(grayCodeMatrix(i, j) + 1) = scrambledImageb(i, j);
    end
end

recoveredImage = uint8(cat(3,recoveredImager,recoveredImageg,recoveredImageb));
% 显示置乱后的图像和恢复后的图像
% figure;
% imshow(recoveredImage,[]), title('恢复后的图像');

% 计算提取水印和原始水印的标准差
std_extracted = std(double(recoveredImage(:)));
std_original = std(double(watermark(:)));
% 计算提取水印和原始水印的协方差矩阵
cov_matrix = cov(double(recoveredImage(:)), double(watermark(:)));
% 计算归一化相关系数（NC）值
NC3 = cov_matrix(1, 2) / (std_extracted * std_original);
%%
recoveredYCbCr = rgb2ycbcr(attackimage4);
recoveredY = recoveredYCbCr(:,:,1);
recoveredCb = recoveredYCbCr(:,:,2);
recoveredCr = recoveredYCbCr(:,:,3);
% 进行整数小波变换的参数设置
wavelet = 'haar'; 
level = 1; 
doubleWImage = double(recoveredY);
% scaledWImage = uint8(doubleWImage * 255);
[c, s1] = wavedec2(doubleWImage, level, wavelet);
cAw = appcoef2(c, s1, wavelet, level); % 低频近似系数
[cHw, cVw, cDw] = detcoef2('all', c, s1, level); % 水平、垂直、对角线细节系数
doubleWImage = double(cAw);
% scaledWImage = uint8(doubleWImage * 255);
[c, s2] = wavedec2(doubleWImage, level, wavelet);
cAw2 = appcoef2(c, s2, wavelet, level); % 低频近似系数
[cHw2, cVw2, cDw2] = detcoef2('all', c, s2, level); % 水平、垂直、对角线细节系数
doubleWImage = double(cAw2);
% scaledWImage = uint8(doubleWImage * 255);
[c, s3] = wavedec2(doubleWImage, level, wavelet);
% 提取各个频带的系数
cAw3 = appcoef2(c, s3, wavelet, level); % 低频近似系数
[cHw3, cVw3, cDw3] = detcoef2('all', c, s3, level); % 水平、垂直、对角线细节系数
%提取水印
[Uwex,Swex,Vwex] = svd(cAw3);
Swe = Uw * Swex * Vw';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Sh)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2 = waverec2([Wex, LHw2, HLw2, HHw2], l, wavelet);
reconstructedImage = waverec2([reconstructedImage2, LHw, HLw, HHw], s, wavelet);
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = U * Shor * V';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cHw3, cVw3, cDw3], s3, waveletName);
or_block2 = waverec2([or_block3, cHw2, cVw2, cDw2], s2, waveletName);
or_block = waverec2([or_block2, cHw, cVw, cDw], s1, waveletName);
% recoveredY((maxRowIndex-1)*blockSize+1:maxRowIndex*blockSize, (maxColIndex-1)*blockSize+1:maxColIndex*blockSize) = or_block;
% figure
% imshow(recoveredY);
recoveredYCbCr(:,:,1) = or_block ;

% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecbw = double(recoveredCb);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s1cbw] = wavedec2(doubleImagecbw, level, waveletName);
% 提取各个频带的系数
cAcbw = appcoef2(c, s1cbw, waveletName, level); % 低频近似系数
[cHcbw, cVcbw, cDcbw] = detcoef2('all', c, s1cbw, level); % 水平、垂直、对角线细节系数
doubleImagecbw = double(cAcbw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s2cbw] = wavedec2(doubleImagecbw, level, waveletName);
% 提取各个频带的系数
cA2cbw = appcoef2(c, s2cbw, waveletName, level); % 低频近似系数
[cH2cbw, cV2cbw, cD2cbw] = detcoef2('all', c, s2cbw, level); % 水平、垂直、对角线细节系数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecbw = double(cA2cbw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s3cbw] = wavedec2(doubleImagecbw, level, waveletName);
% 提取各个频带的系数
cA3cbw = appcoef2(c, s3cbw, waveletName, level); % 低频近似系数
[cH3cbw, cV3cbw, cD3cbw] = detcoef2('all', c, s3cbw, level); % 水平、垂直、对角线细节系数

%提取水印
[Uwex,Swex,Vwex] = svd(cA3cbw);
Swe = Uwcb * Swex * Vwcb';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Shcb)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2g = waverec2([Wex, LHw2g, HLw2g, HHw2g], lg, wavelet);
reconstructedImageg = waverec2([reconstructedImage2g, LHwg, HLwg, HHwg], sg, wavelet);
% figure
% imshow(reconstructedImage)
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = Ucb * Shor * Vcb';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cH3cbw, cV3cbw, cD3cbw], s3cbw, waveletName);
or_block2 = waverec2([or_block3, cH2cbw, cV2cbw, cD2cbw], s2cbw, waveletName);
or_block = waverec2([or_block2, cHcbw, cVcbw, cDcbw], s1cbw, waveletName);
% recoveredY((maxRowIndex-1)*blockSize+1:maxRowIndex*blockSize, (maxColIndex-1)*blockSize+1:maxColIndex*blockSize) = or_block;
% figure
% imshow(recoveredY);
recoveredYCbCr(:,:,2) = or_block ;


% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecrw = double(recoveredCr);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s1crw] = wavedec2(doubleImagecrw, level, waveletName);
% 提取各个频带的系数
cAcrw = appcoef2(c, s1crw, waveletName, level); % 低频近似系数
[cHcrw, cVcrw, cDcrw] = detcoef2('all', c, s1crw, level); % 水平、垂直、对角线细节系数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecrw = double(cAcrw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s2crw] = wavedec2(doubleImagecrw, level, waveletName);
% 提取各个频带的系数
cA2crw = appcoef2(c, s2crw, waveletName, level); % 低频近似系数
[cH2crw, cV2crw, cD2crw] = detcoef2('all', c, s2crw, level); % 水平、垂直、对角线细节系数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecrw = double(cA2crw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s3crw] = wavedec2(doubleImagecrw, level, waveletName);
% 提取各个频带的系数
cA3crw = appcoef2(c, s3crw, waveletName, level); % 低频近似系数
[cH3crw, cV3crw, cD3crw] = detcoef2('all', c, s3crw, level); % 水平、垂直、对角线细节系数

%提取水印
[Uwex,Swex,Vwex] = svd(cA3crw);
Swe = Uwcr * Swex * Vwcr';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Shcr)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2b = waverec2([Wex, LHw2b, HLw2b, HHw2b], lb, wavelet);
reconstructedImageb = waverec2([reconstructedImage2b, LHwb, HLwb, HHwb], sb, wavelet);
% figure
% imshow(reconstructedImage)
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = Ucr * Shor * Vcr';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cH3crw, cV3crw, cD3crw], s3crw, waveletName);
or_block2 = waverec2([or_block3, cH2crw, cV2crw, cD2crw], s2crw, waveletName);
or_block = waverec2([or_block2, cHcrw, cVcrw, cDcrw], s1crw, waveletName);
% recoveredY((maxRowIndex-1)*blockSize+1:maxRowIndex*blockSize, (maxColIndex-1)*blockSize+1:maxColIndex*blockSize) = or_block;
% figure
% imshow(recoveredY);
recoveredYCbCr(:,:,3) = or_block ;
originalImage = ycbcr2rgb(recoveredYCbCr);
% figure
% imshow(originalImage);title('恢复的原始图像');
% 计算 PSNR 值
% psnrval= psnr(originalImage, Original);
% disp(['The PSNR value is ', num2str(psnrval,'%.4f')]);
% % 计算SSIM值
% ssimValue = ssim(originalImage, Original);
% disp(['嵌入水印图像的SSIM值为：', num2str(ssimValue,'%.4f')]);

% 将水印图像还原
unscrambled_w = arnoldUnscramble(reconstructedImage);
unscrambled_wg = arnoldUnscramble(reconstructedImageg);
unscrambled_wb = arnoldUnscramble(reconstructedImageb);

% 读取置乱后的图像
scrambledImager = unscrambled_w;
% 图像参数
[M, N] = size(scrambledImager);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImager = zeros(M, N, 'like', scrambledImager);
for i = 1:M
    for j = 1:N
        recoveredImager(grayCodeMatrix(i, j) + 1) = scrambledImager(i, j);
    end
end

% 读取置乱后的图像
scrambledImageg = unscrambled_wg;
% 图像参数
[M, N] = size(scrambledImageg);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImageg = zeros(M, N, 'like', scrambledImageg);
for i = 1:M
    for j = 1:N
        recoveredImageg(grayCodeMatrix(i, j) + 1) = scrambledImageg(i, j);
    end
end

% 读取置乱后的图像
scrambledImageb = unscrambled_wb;
% 图像参数
[M, N] = size(scrambledImageb);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImageb = zeros(M, N, 'like', scrambledImageb);
for i = 1:M
    for j = 1:N
        recoveredImageb(grayCodeMatrix(i, j) + 1) = scrambledImageb(i, j);
    end
end

recoveredImage = uint8(cat(3,recoveredImager,recoveredImageg,recoveredImageb));
% 显示置乱后的图像和恢复后的图像
% figure;
% imshow(recoveredImage,[]), title('恢复后的图像');

% 计算提取水印和原始水印的标准差
std_extracted = std(double(recoveredImage(:)));
std_original = std(double(watermark(:)));
% 计算提取水印和原始水印的协方差矩阵
cov_matrix = cov(double(recoveredImage(:)), double(watermark(:)));
% 计算归一化相关系数（NC）值
NC4 = cov_matrix(1, 2) / (std_extracted * std_original);
%%
recoveredYCbCr = rgb2ycbcr(attackimage5);
recoveredY = recoveredYCbCr(:,:,1);
recoveredCb = recoveredYCbCr(:,:,2);
recoveredCr = recoveredYCbCr(:,:,3);
% 进行整数小波变换的参数设置
wavelet = 'haar'; 
level = 1; 
doubleWImage = double(recoveredY);
% scaledWImage = uint8(doubleWImage * 255);
[c, s1] = wavedec2(doubleWImage, level, wavelet);
cAw = appcoef2(c, s1, wavelet, level); % 低频近似系数
[cHw, cVw, cDw] = detcoef2('all', c, s1, level); % 水平、垂直、对角线细节系数
doubleWImage = double(cAw);
% scaledWImage = uint8(doubleWImage * 255);
[c, s2] = wavedec2(doubleWImage, level, wavelet);
cAw2 = appcoef2(c, s2, wavelet, level); % 低频近似系数
[cHw2, cVw2, cDw2] = detcoef2('all', c, s2, level); % 水平、垂直、对角线细节系数
doubleWImage = double(cAw2);
% scaledWImage = uint8(doubleWImage * 255);
[c, s3] = wavedec2(doubleWImage, level, wavelet);
% 提取各个频带的系数
cAw3 = appcoef2(c, s3, wavelet, level); % 低频近似系数
[cHw3, cVw3, cDw3] = detcoef2('all', c, s3, level); % 水平、垂直、对角线细节系数
%提取水印
[Uwex,Swex,Vwex] = svd(cAw3);
Swe = Uw * Swex * Vw';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Sh)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2 = waverec2([Wex, LHw2, HLw2, HHw2], l, wavelet);
reconstructedImage = waverec2([reconstructedImage2, LHw, HLw, HHw], s, wavelet);
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = U * Shor * V';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cHw3, cVw3, cDw3], s3, waveletName);
or_block2 = waverec2([or_block3, cHw2, cVw2, cDw2], s2, waveletName);
or_block = waverec2([or_block2, cHw, cVw, cDw], s1, waveletName);
% recoveredY((maxRowIndex-1)*blockSize+1:maxRowIndex*blockSize, (maxColIndex-1)*blockSize+1:maxColIndex*blockSize) = or_block;
% figure
% imshow(recoveredY);
recoveredYCbCr(:,:,1) = or_block ;

% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecbw = double(recoveredCb);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s1cbw] = wavedec2(doubleImagecbw, level, waveletName);
% 提取各个频带的系数
cAcbw = appcoef2(c, s1cbw, waveletName, level); % 低频近似系数
[cHcbw, cVcbw, cDcbw] = detcoef2('all', c, s1cbw, level); % 水平、垂直、对角线细节系数
doubleImagecbw = double(cAcbw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s2cbw] = wavedec2(doubleImagecbw, level, waveletName);
% 提取各个频带的系数
cA2cbw = appcoef2(c, s2cbw, waveletName, level); % 低频近似系数
[cH2cbw, cV2cbw, cD2cbw] = detcoef2('all', c, s2cbw, level); % 水平、垂直、对角线细节系数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecbw = double(cA2cbw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s3cbw] = wavedec2(doubleImagecbw, level, waveletName);
% 提取各个频带的系数
cA3cbw = appcoef2(c, s3cbw, waveletName, level); % 低频近似系数
[cH3cbw, cV3cbw, cD3cbw] = detcoef2('all', c, s3cbw, level); % 水平、垂直、对角线细节系数

%提取水印
[Uwex,Swex,Vwex] = svd(cA3cbw);
Swe = Uwcb * Swex * Vwcb';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Shcb)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2g = waverec2([Wex, LHw2g, HLw2g, HHw2g], lg, wavelet);
reconstructedImageg = waverec2([reconstructedImage2g, LHwg, HLwg, HHwg], sg, wavelet);
% figure
% imshow(reconstructedImage)
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = Ucb * Shor * Vcb';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cH3cbw, cV3cbw, cD3cbw], s3cbw, waveletName);
or_block2 = waverec2([or_block3, cH2cbw, cV2cbw, cD2cbw], s2cbw, waveletName);
or_block = waverec2([or_block2, cHcbw, cVcbw, cDcbw], s1cbw, waveletName);
% recoveredY((maxRowIndex-1)*blockSize+1:maxRowIndex*blockSize, (maxColIndex-1)*blockSize+1:maxColIndex*blockSize) = or_block;
% figure
% imshow(recoveredY);
recoveredYCbCr(:,:,2) = or_block ;
% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecrw = double(recoveredCr);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s1crw] = wavedec2(doubleImagecrw, level, waveletName);
% 提取各个频带的系数
cAcrw = appcoef2(c, s1crw, waveletName, level); % 低频近似系数
[cHcrw, cVcrw, cDcrw] = detcoef2('all', c, s1crw, level); % 水平、垂直、对角线细节系数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecrw = double(cAcrw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s2crw] = wavedec2(doubleImagecrw, level, waveletName);
% 提取各个频带的系数
cA2crw = appcoef2(c, s2crw, waveletName, level); % 低频近似系数
[cH2crw, cV2crw, cD2crw] = detcoef2('all', c, s2crw, level); % 水平、垂直、对角线细节系数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecrw = double(cA2crw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s3crw] = wavedec2(doubleImagecrw, level, waveletName);
% 提取各个频带的系数
cA3crw = appcoef2(c, s3crw, waveletName, level); % 低频近似系数
[cH3crw, cV3crw, cD3crw] = detcoef2('all', c, s3crw, level); % 水平、垂直、对角线细节系数

%提取水印
[Uwex,Swex,Vwex] = svd(cA3crw);
Swe = Uwcr * Swex * Vwcr';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Shcr)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2b = waverec2([Wex, LHw2b, HLw2b, HHw2b], lb, wavelet);
reconstructedImageb = waverec2([reconstructedImage2b, LHwb, HLwb, HHwb], sb, wavelet);
% figure
% imshow(reconstructedImage)
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = Ucr * Shor * Vcr';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cH3crw, cV3crw, cD3crw], s3crw, waveletName);
or_block2 = waverec2([or_block3, cH2crw, cV2crw, cD2crw], s2crw, waveletName);
or_block = waverec2([or_block2, cHcrw, cVcrw, cDcrw], s1crw, waveletName);
% recoveredY((maxRowIndex-1)*blockSize+1:maxRowIndex*blockSize, (maxColIndex-1)*blockSize+1:maxColIndex*blockSize) = or_block;
% figure
% imshow(recoveredY);
recoveredYCbCr(:,:,3) = or_block ;
originalImage = ycbcr2rgb(recoveredYCbCr);
% figure
% imshow(originalImage);title('恢复的原始图像');
% 计算 PSNR 值
% psnrval= psnr(originalImage, Original);
% disp(['The PSNR value is ', num2str(psnrval,'%.4f')]);
% % 计算SSIM值
% ssimValue = ssim(originalImage, Original);
% disp(['嵌入水印图像的SSIM值为：', num2str(ssimValue,'%.4f')]);

% 将水印图像还原
unscrambled_w = arnoldUnscramble(reconstructedImage);
unscrambled_wg = arnoldUnscramble(reconstructedImageg);
unscrambled_wb = arnoldUnscramble(reconstructedImageb);

% 读取置乱后的图像
scrambledImager = unscrambled_w;
% 图像参数
[M, N] = size(scrambledImager);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImager = zeros(M, N, 'like', scrambledImager);
for i = 1:M
    for j = 1:N
        recoveredImager(grayCodeMatrix(i, j) + 1) = scrambledImager(i, j);
    end
end

% 读取置乱后的图像
scrambledImageg = unscrambled_wg;
% 图像参数
[M, N] = size(scrambledImageg);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImageg = zeros(M, N, 'like', scrambledImageg);
for i = 1:M
    for j = 1:N
        recoveredImageg(grayCodeMatrix(i, j) + 1) = scrambledImageg(i, j);
    end
end

% 读取置乱后的图像
scrambledImageb = unscrambled_wb;
% 图像参数
[M, N] = size(scrambledImageb);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImageb = zeros(M, N, 'like', scrambledImageb);
for i = 1:M
    for j = 1:N
        recoveredImageb(grayCodeMatrix(i, j) + 1) = scrambledImageb(i, j);
    end
end

recoveredImage = uint8(cat(3,recoveredImager,recoveredImageg,recoveredImageb));
% 显示置乱后的图像和恢复后的图像
% figure;
% imshow(recoveredImage,[]), title('恢复后的图像');

% 计算提取水印和原始水印的标准差
std_extracted = std(double(recoveredImage(:)));
std_original = std(double(watermark(:)));
% 计算提取水印和原始水印的协方差矩阵
cov_matrix = cov(double(recoveredImage(:)), double(watermark(:)));
% 计算归一化相关系数（NC）值
NC5 = cov_matrix(1, 2) / (std_extracted * std_original);
%%
recoveredYCbCr = rgb2ycbcr(attackimage6);
recoveredY = recoveredYCbCr(:,:,1);
recoveredCb = recoveredYCbCr(:,:,2);
recoveredCr = recoveredYCbCr(:,:,3);
% 进行整数小波变换的参数设置
wavelet = 'haar'; 
level = 1; 
doubleWImage = double(recoveredY);
% scaledWImage = uint8(doubleWImage * 255);
[c, s1] = wavedec2(doubleWImage, level, wavelet);
cAw = appcoef2(c, s1, wavelet, level); % 低频近似系数
[cHw, cVw, cDw] = detcoef2('all', c, s1, level); % 水平、垂直、对角线细节系数
doubleWImage = double(cAw);
% scaledWImage = uint8(doubleWImage * 255);
[c, s2] = wavedec2(doubleWImage, level, wavelet);
cAw2 = appcoef2(c, s2, wavelet, level); % 低频近似系数
[cHw2, cVw2, cDw2] = detcoef2('all', c, s2, level); % 水平、垂直、对角线细节系数
doubleWImage = double(cAw2);
% scaledWImage = uint8(doubleWImage * 255);
[c, s3] = wavedec2(doubleWImage, level, wavelet);
% 提取各个频带的系数
cAw3 = appcoef2(c, s3, wavelet, level); % 低频近似系数
[cHw3, cVw3, cDw3] = detcoef2('all', c, s3, level); % 水平、垂直、对角线细节系数
%提取水印
[Uwex,Swex,Vwex] = svd(cAw3);
Swe = Uw * Swex * Vw';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Sh)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2 = waverec2([Wex, LHw2, HLw2, HHw2], l, wavelet);
reconstructedImage = waverec2([reconstructedImage2, LHw, HLw, HHw], s, wavelet);
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = U * Shor * V';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cHw3, cVw3, cDw3], s3, waveletName);
or_block2 = waverec2([or_block3, cHw2, cVw2, cDw2], s2, waveletName);
or_block = waverec2([or_block2, cHw, cVw, cDw], s1, waveletName);
% recoveredY((maxRowIndex-1)*blockSize+1:maxRowIndex*blockSize, (maxColIndex-1)*blockSize+1:maxColIndex*blockSize) = or_block;
% figure
% imshow(recoveredY);
recoveredYCbCr(:,:,1) = or_block ;

% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecbw = double(recoveredCb);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s1cbw] = wavedec2(doubleImagecbw, level, waveletName);
% 提取各个频带的系数
cAcbw = appcoef2(c, s1cbw, waveletName, level); % 低频近似系数
[cHcbw, cVcbw, cDcbw] = detcoef2('all', c, s1cbw, level); % 水平、垂直、对角线细节系数
doubleImagecbw = double(cAcbw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s2cbw] = wavedec2(doubleImagecbw, level, waveletName);
% 提取各个频带的系数
cA2cbw = appcoef2(c, s2cbw, waveletName, level); % 低频近似系数
[cH2cbw, cV2cbw, cD2cbw] = detcoef2('all', c, s2cbw, level); % 水平、垂直、对角线细节系数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecbw = double(cA2cbw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s3cbw] = wavedec2(doubleImagecbw, level, waveletName);
% 提取各个频带的系数
cA3cbw = appcoef2(c, s3cbw, waveletName, level); % 低频近似系数
[cH3cbw, cV3cbw, cD3cbw] = detcoef2('all', c, s3cbw, level); % 水平、垂直、对角线细节系数

%提取水印
[Uwex,Swex,Vwex] = svd(cA3cbw);
Swe = Uwcb * Swex * Vwcb';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Shcb)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2g = waverec2([Wex, LHw2g, HLw2g, HHw2g], lg, wavelet);
reconstructedImageg = waverec2([reconstructedImage2g, LHwg, HLwg, HHwg], sg, wavelet);
% figure
% imshow(reconstructedImage)
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = Ucb * Shor * Vcb';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cH3cbw, cV3cbw, cD3cbw], s3cbw, waveletName);
or_block2 = waverec2([or_block3, cH2cbw, cV2cbw, cD2cbw], s2cbw, waveletName);
or_block = waverec2([or_block2, cHcbw, cVcbw, cDcbw], s1cbw, waveletName);
% recoveredY((maxRowIndex-1)*blockSize+1:maxRowIndex*blockSize, (maxColIndex-1)*blockSize+1:maxColIndex*blockSize) = or_block;
% figure
% imshow(recoveredY);
recoveredYCbCr(:,:,2) = or_block ;


% 进行整数小波变换的参数设置
waveletName = 'haar'; % 小波函数名称，这里使用 Haar 小波
level = 1; % 变换的层数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecrw = double(recoveredCr);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s1crw] = wavedec2(doubleImagecrw, level, waveletName);
% 提取各个频带的系数
cAcrw = appcoef2(c, s1crw, waveletName, level); % 低频近似系数
[cHcrw, cVcrw, cDcrw] = detcoef2('all', c, s1crw, level); % 水平、垂直、对角线细节系数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecrw = double(cAcrw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s2crw] = wavedec2(doubleImagecrw, level, waveletName);
% 提取各个频带的系数
cA2crw = appcoef2(c, s2crw, waveletName, level); % 低频近似系数
[cH2crw, cV2crw, cD2crw] = detcoef2('all', c, s2crw, level); % 水平、垂直、对角线细节系数
% 将灰度图像转换为 double 类型的数据，并将像素值缩放到 [0, 255] 的整数范围
doubleImagecrw = double(cA2crw);
% scaledImage = uint8(doubleImage * 255);
% 执行整数小波变换
[c, s3crw] = wavedec2(doubleImagecrw, level, waveletName);
% 提取各个频带的系数
cA3crw = appcoef2(c, s3crw, waveletName, level); % 低频近似系数
[cH3crw, cV3crw, cD3crw] = detcoef2('all', c, s3crw, level); % 水平、垂直、对角线细节系数

%提取水印
[Uwex,Swex,Vwex] = svd(cA3crw);
Swe = Uwcr * Swex * Vwcr';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Shcr)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2b = waverec2([Wex, LHw2b, HLw2b, HHw2b], lb, wavelet);
reconstructedImageb = waverec2([reconstructedImage2b, LHwb, HLwb, HHwb], sb, wavelet);
% figure
% imshow(reconstructedImage)
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = Ucr * Shor * Vcr';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cH3crw, cV3crw, cD3crw], s3crw, waveletName);
or_block2 = waverec2([or_block3, cH2crw, cV2crw, cD2crw], s2crw, waveletName);
or_block = waverec2([or_block2, cHcrw, cVcrw, cDcrw], s1crw, waveletName);
% recoveredY((maxRowIndex-1)*blockSize+1:maxRowIndex*blockSize, (maxColIndex-1)*blockSize+1:maxColIndex*blockSize) = or_block;
% figure
% imshow(recoveredY);
recoveredYCbCr(:,:,3) = or_block ;
originalImage = ycbcr2rgb(recoveredYCbCr);
% figure
% imshow(originalImage);title('恢复的原始图像');
% 计算 PSNR 值
% psnrval= psnr(originalImage, Original);
% disp(['The PSNR value is ', num2str(psnrval,'%.4f')]);
% % 计算SSIM值
% ssimValue = ssim(originalImage, Original);
% disp(['嵌入水印图像的SSIM值为：', num2str(ssimValue,'%.4f')]);

% 将水印图像还原
unscrambled_w = arnoldUnscramble(reconstructedImage);
unscrambled_wg = arnoldUnscramble(reconstructedImageg);
unscrambled_wb = arnoldUnscramble(reconstructedImageb);

% 读取置乱后的图像
scrambledImager = unscrambled_w;
% 图像参数
[M, N] = size(scrambledImager);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImager = zeros(M, N, 'like', scrambledImager);
for i = 1:M
    for j = 1:N
        recoveredImager(grayCodeMatrix(i, j) + 1) = scrambledImager(i, j);
    end
end

% 读取置乱后的图像
scrambledImageg = unscrambled_wg;
% 图像参数
[M, N] = size(scrambledImageg);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImageg = zeros(M, N, 'like', scrambledImageg);
for i = 1:M
    for j = 1:N
        recoveredImageg(grayCodeMatrix(i, j) + 1) = scrambledImageg(i, j);
    end
end

% 读取置乱后的图像
scrambledImageb = unscrambled_wb;
% 图像参数
[M, N] = size(scrambledImageb);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImageb = zeros(M, N, 'like', scrambledImageb);
for i = 1:M
    for j = 1:N
        recoveredImageb(grayCodeMatrix(i, j) + 1) = scrambledImageb(i, j);
    end
end

recoveredImage = uint8(cat(3,recoveredImager,recoveredImageg,recoveredImageb));
% 显示置乱后的图像和恢复后的图像
% figure;
% imshow(recoveredImage,[]), title('恢复后的图像');

% 计算提取水印和原始水印的标准差
std_extracted = std(double(recoveredImage(:)));
std_original = std(double(watermark(:)));
% 计算提取水印和原始水印的协方差矩阵
cov_matrix = cov(double(recoveredImage(:)), double(watermark(:)));
% 计算归一化相关系数（NC）值
NC6 = cov_matrix(1, 2) / (std_extracted * std_original);

% 显示 NC 值
% disp(num2str(NC,'%.4f'));
    % 在这个函数中，根据 alpha 进行奇异值分解方法的水印嵌入
    % 然后计算图像的 PSNR、SSIM 和 NC 值，并返回它们的加权和的倒数作为适应度值
    % 假设 watermark_embedding 函数用于进行水印嵌入
%     watermarked_image = watermark_embedding(alpha);
%     original_image = imread('original_image.jpg'); % 读取原始图像
    % 综合考虑 PSNR、SSIM 和 NC 的值，并返回它们的加权和的倒数作为适应度值
    fitness = 1/psnrval + ssimValue + (NC1+NC2+NC3+NC4+NC5+NC6)/6;
end

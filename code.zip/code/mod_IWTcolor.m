tic;
clear;
close all;
% Original=imread('lena.jpg');
% Original=imread('house.jpg');
% Original=imread('babooncolor.tif');
Original=imread('Pepppers.tiff');
% Original=imread('Airplane.tiff');
% Original=imread('Sailboat.tiff');
% Original=imread('barbara.bmp');
% imshow(Original)
% imageFiles = {'lena.jpg', 'babooncolor.tif', 'Pepppers.tiff', 'Airplane.tiff', 'Sailboat.tiff', 'barbara.bmp'};
% for i = 1:length(imageFiles)
%     Original = imread(imageFiles{i});
% % 指定新的尺寸
% newSize = [512, 512]; % 新的宽度和高度
% resizedImage = imresize(Original, newSize);
% imwrite(resizedImage,'Pepppers.bmp')
watermark=imread('Peugeot.bmp');
% watermark=imread('W4.bmp');
% 指定新的尺寸
% newSize = [256, 256]; % 新的宽度和高度
% resizedImage = imresize(watermark, newSize);
% imwrite(resizedImage,'W4.bmp')
watermarkr=watermark(:,:,1);
watermarkg=watermark(:,:,2);
watermarkb=watermark(:,:,3);

% 读取图像
grayImager = watermarkr;
% 图像参数
[M, N] = size(grayImager);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行置乱
scrambledimager = zeros(M, N, 'like', grayImager);
for i = 1:M
    for j = 1:N
        scrambledimager(i, j) = grayImager(grayCodeMatrix(i, j) + 1);
    end
end
scrambledr = Scramble(scrambledimager);

% 读取图像
grayImageg = watermarkg;
% 图像参数
[M, N] = size(grayImageg);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行置乱
scrambledimageg = zeros(M, N, 'like', grayImageg);
for i = 1:M
    for j = 1:N
        scrambledimageg(i, j) = grayImageg(grayCodeMatrix(i, j) + 1);
    end
end
scrambledg = Scramble(scrambledimageg);

% 读取图像
grayImageb = watermarkb;
[M, N] = size(grayImageb);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行置乱
scrambledimageb = zeros(M, N, 'like', grayImageb);
for i = 1:M
    for j = 1:N
        scrambledimageb(i, j) = grayImageb(grayCodeMatrix(i, j) + 1);
    end
end
scrambledb = Scramble(scrambledimageb);

% 进行整数小波变换的参数设置
waveletName = 'haar'; 
level = 1;
doublewatermarkr = double(scrambledr);
[c, s] = wavedec2(doublewatermarkr, level, waveletName);
LLw = appcoef2(c, s, waveletName, level); 
[LHw, HLw, HHw] = detcoef2('all', c, s, level); 
doublewatermark = double(LLw);
[c, l] = wavedec2(doublewatermark, level, waveletName);
LLw2 = appcoef2(c, l, waveletName, level); 
[LHw2, HLw2, HHw2] = detcoef2('all', c, l, level); 

doublewatermarkg = double(scrambledg);
[c, sg] = wavedec2(doublewatermarkg, level, waveletName);
% 提取各个频带的系数
LLwg = appcoef2(c, sg, waveletName, level); 
[LHwg, HLwg, HHwg] = detcoef2('all', c, sg, level); 
doublewatermarkg = double(LLwg);
[c, lg] = wavedec2(doublewatermarkg, level, waveletName);
% 提取各个频带的系数
LLw2g = appcoef2(c, lg, waveletName, level); 
[LHw2g, HLw2g, HHw2g] = detcoef2('all', c, lg, level);

doublewatermarkb = double(scrambledb);
[c, sb] = wavedec2(doublewatermarkb, level, waveletName);
LLwb = appcoef2(c, sb, waveletName, level);
[LHwb, HLwb, HHwb] = detcoef2('all', c, sb, level); 
doublewatermarkb = double(LLwb);
[c, lb] = wavedec2(doublewatermarkb, level, waveletName);
LLw2b = appcoef2(c, lb, waveletName, level); 
[LHw2b, HLw2b, HHw2b] = detcoef2('all', c, lb, level); 
%% Original image
ycbcr_image = rgb2ycbcr(Original); 
Y = ycbcr_image(:,:,1);
Cb = ycbcr_image(:,:,2);
Cr = ycbcr_image(:,:,3);

waveletName = 'haar'; 
level = 1; 
doubleImage = double(Y);
[c, s1] = wavedec2(doubleImage, level, waveletName);
cA = appcoef2(c, s1, waveletName, level); 
[cH, cV, cD] = detcoef2('all', c, s1, level); 
waveletName = 'haar'; 
doubleImage = double(cA);
[c, s2] = wavedec2(doubleImage, level, waveletName);
cA2 = appcoef2(c, s2, waveletName, level);
[cH2, cV2, cD2] = detcoef2('all', c, s2, level); 
waveletName = 'haar';
doubleImage = double(cA2);
[c, s3] = wavedec2(doubleImage, level, waveletName);
cA3 = appcoef2(c, s3, waveletName, level); 
[cH3, cV3, cD3] = detcoef2('all', c, s3, level);

doubleImagecb = double(Cb);
[c, s1cb] = wavedec2(doubleImagecb, level, waveletName);
cAcb = appcoef2(c, s1cb, waveletName, level);
[cHcb, cVcb, cDcb] = detcoef2('all', c, s1cb, level); 
doubleImagecb = double(cAcb);
[c, s2cb] = wavedec2(doubleImagecb, level, waveletName);
cA2cb = appcoef2(c, s2cb, waveletName, level); 
[cH2cb, cV2cb, cD2cb] = detcoef2('all', c, s2cb, level);
doubleImagecb = double(cA2cb);
[c, s3cb] = wavedec2(doubleImagecb, level, waveletName);
cA3cb = appcoef2(c, s3cb, waveletName, level); 
[cH3cb, cV3cb, cD3cb] = detcoef2('all', c, s3cb, level);

doubleImagecr = double(Cr);
[c, s1cr] = wavedec2(doubleImagecr, level, waveletName);
cAcr = appcoef2(c, s1cr, waveletName, level); 
[cHcr, cVcr, cDcr] = detcoef2('all', c, s1cr, level); 
doubleImagecr = double(cAcr);
[c, s2cr] = wavedec2(doubleImagecr, level, waveletName);
cA2cr = appcoef2(c, s2cr, waveletName, level); 
[cH2cr, cV2cr, cD2cr] = detcoef2('all', c, s2cr, level); 
doubleImagecr = double(cA2cr);
[c, s3cr] = wavedec2(doubleImagecr, level, waveletName);
cA3cr = appcoef2(c, s3cr, waveletName, level); 
[HAwatermarkedImage, cV3cr, cD3cr] = detcoef2('all', c, s3cr, level); 
%% 嵌入低频子带
grayImg = cA3;
grayWatermark = LLw2;
H = hadamard(64);
inverseH = H' / 64;
% 对图像进行SVD分解
[U, S, V] = svd(grayImg);
Sh = H * S;
hw = H * grayWatermark;
% 嵌入水印图像
% for alpha = 0.01: 0.005 : 0.2
alpha = 0.072;
Sh_watermarked = Sh + alpha * hw;
%逆哈达玛
Sh_wa = inverseH * Sh_watermarked;
[Uw,Sw,Vw] = svd(Sh_wa); 
% 嵌入水印后的图像逆SVD
reconstructedImg = U * Sw * V';
embedded_block3 = waverec2([reconstructedImg, cH3, cV3, cD3], s3, waveletName);
embedded_block2 = waverec2([embedded_block3 , cH2, cV2, cD2], s2, waveletName);
embedded_block = waverec2([embedded_block2, cH, cV, cD], s1, waveletName);
% figure
% imshow(embedded_block)
round_y=round(embedded_block);
rounding_error = embedded_block - round_y;
ycbcr_image(:,:,1) = round_y;

grayImgcb = cA3cb;
grayWatermarkg = LLw2g;
% 对图像进行SVD分解
[Ucb, Scb, Vcb] = svd(grayImgcb);
% 对S进行哈达玛变换
Shcb = H * Scb;
hwg = H * grayWatermarkg;
% 嵌入水印图像
Sh_watermarkedcb = Shcb + alpha * hwg;
%逆哈达玛
Sh_wacb = inverseH * Sh_watermarkedcb;
[Uwcb,Swcb,Vwcb] = svd(Sh_wacb); 
% 嵌入水印后的图像逆SVD
reconstructedImgcb = Ucb * Swcb * Vcb';
embedded_block3cb = waverec2([reconstructedImgcb, cH3cb, cV3cb, cD3cb], s3cb, waveletName);
embedded_block2cb = waverec2([embedded_block3cb , cH2cb, cV2cb, cD2cb], s2cb, waveletName);
embedded_blockcb = waverec2([embedded_block2cb, cHcb, cVcb, cDcb], s1cb, waveletName);
% 创建YCbCr图像
round_cb=round(embedded_blockcb);
rounding_error2 = embedded_blockcb - round_cb;
ycbcr_image(:,:,2) = round_cb;

grayImgcr = cA3cr;
grayWatermarkb = LLw2b;
% 对图像进行SVD分解
[Ucr, Scr, Vcr] = svd(grayImgcr);
% 对S进行哈达玛变换
Shcr = H * Scr;
hwb = H * grayWatermarkb;
% 嵌入水印图像
Sh_watermarkedcr = Shcr + alpha * hwb;
%逆哈达玛
Sh_wacr = inverseH * Sh_watermarkedcr;
[Uwcr,Swcr,Vwcr] = svd(Sh_wacr); 
% 嵌入水印后的图像逆SVD
reconstructedImgcr = Ucr * Swcr * Vcr';
embedded_block3cr = waverec2([reconstructedImgcr, HAwatermarkedImage, cV3cr, cD3cr], s3cr, waveletName);
embedded_block2cr = waverec2([embedded_block3cr , cH2cr, cV2cr, cD2cr], s2cr, waveletName);
embedded_blockcr = waverec2([embedded_block2cr, cHcr, cVcr, cDcr], s1cr, waveletName);
% 创建YCbCr图像
round_cr=round(embedded_blockcr);
rounding_error3 = embedded_blockcr - round_cr;
ycbcr_image(:,:,3) = round_cr;
watermarkedImage = ycbcr2rgb(ycbcr_image);
figure
imshow(watermarkedImage);title('Image Converted to RGB');
% imwrite(watermarkedImage,'shuiyintu.jpg')
% Results
% figure
% subplot(2,2,1),imshow(Original),title('Original image');
% subplot(2,2,2),imshow(watermark),title('watermark image');
% subplot(2,2,3),imshow(RGB2),title('watermarked image');

% 计算 PSNR 值
psnrval= psnr(watermarkedImage, Original);
disp(num2str(psnrval));
% disp(['The PSNR value is ', num2str(psnrval,'%.4f')]);

% 计算SSIM值
ssimValue = ssim(watermarkedImage, Original);
disp(['嵌入水印图像的SSIM值为：', num2str(ssimValue,'%.4f')]);


%%
% 分离颜色通道,应用3x3中值滤波器,合并颜色通道
rChannel = watermarkedImage(:,:,1);
gChannel = watermarkedImage(:,:,2);
bChannel = watermarkedImage(:,:,3);
rMedian = medfilt2(rChannel, [2 2]);
gMedian = medfilt2(gChannel, [2 2]);
bMedian = medfilt2(bChannel, [2 2]);
% rMedian = medfilt2(rChannel, [5 5]);
% gMedian = medfilt2(gChannel, [5 5]);
% bMedian = medfilt2(bChannel, [5 5]);
attackimage1 = cat(3, rMedian, gMedian, bMedian);
% 应用平均过滤器,定义平均过滤器
filter = fspecial('average', 3);
attackimage2 = imfilter(watermarkedImage, filter);
% 对图像进行滤波,生成3x3高斯滤波器
h = fspecial('gaussian',5);
attackimage3 = imfilter(watermarkedImage, h);
% 应用椒盐噪声攻击
attackimage4 = imnoise(watermarkedImage, 'salt & pepper', 0.1);
% 添加高斯噪声到水印图像
attackimage5= imnoise(watermarkedImage, 'gaussian', 0, 0.08);
% 添加Speckle噪声
attackimage6 = imnoise(watermarkedImage, 'speckle', 0.01);
% 对水印图像进行JPEG压缩,设置压缩质量，此处设置为70%
quality =90;
imwrite(watermarkedImage, 'compressed_watermark.jpg', 'Quality', quality);
attackimage7=imread('compressed_watermark.jpg');
% % 压缩图像并保存,设置 JPEG2000 压缩参数
imwrite(watermarkedImage, 'compressed_image.jp2', 'jp2', 'Mode', 'lossy', 'CompressionRatio', 5);
attackimage8 = imread('compressed_image.jp2');
% 对图像进行锐化
attackimage9 = imsharpen(watermarkedImage,'Amount', 1);
% 对RGB三个通道分别进行伽马校正
R = imadjust(watermarkedImage(:,:,1), [], [], 0.8);
G = imadjust(watermarkedImage(:,:,2), [], [], 0.8);
B = imadjust(watermarkedImage(:,:,3), [], [], 0.8);
attackimage10 = cat(3, R, G, B);
% % 对比度调整
% attackimage = imadjust(watermarkedImage, [], [], 1.1);
% attackimage10 = imadjust(watermarkedImage, [0.1 0.9], []);
% % 进行直方图均衡化
attackimage11 = histeq(watermarkedImage);
% % 将图像旋转20度
attackimage12 = imrotate(watermarkedImage, 60, 'crop');
% % 获取图像尺寸 裁剪左半边区域
[rows, cols, ~] = size(watermarkedImage);
attackimage = watermarkedImage;
% attackimage(:, 1:cols/2, :) = 0; % 将左半边区域置为黑色
% attackimage(:, 1:round(cols/4), :) = 0;
attackimage(:, round(3*cols/4):cols, :) = 0;
% % 计算 Shear 参数,进行 Shear 操作并保持原始图像大小
shear_factor = 0.1;
tform = affine2d([1 shear_factor 0; shear_factor 1 0; 0 0 1]);
output_size = size(watermarkedImage);
attackimage13 = imwarp(watermarkedImage, tform, 'OutputView', imref2d(output_size));

% tform = affine2d([1 0 0; 0.08 1 0; 0 0 1]);
% % 对图像进行剪切操作
% output_size = size(watermarkedImage);
% attackimage13 = imwarp(watermarkedImage, tform, 'OutputView', imref2d(output_size));
% 读取原始图像
original_image = watermarkedImage;
% 缩放比例
scale_factor = 0.7;
% 计算缩放后的图像大小
scaled_rows = round(size(original_image, 1) * scale_factor);
scaled_cols = round(size(original_image, 2) * scale_factor);
% 创建一个与原始图像相同大小的黑色图像
resized_image = zeros(size(original_image), 'like', original_image);
% 计算缩放后的图像在原始图像中的位置
start_row = round((size(original_image, 1) - scaled_rows) / 2);
start_col = round((size(original_image, 2) - scaled_cols) / 2);
end_row = start_row + scaled_rows - 1;
end_col = start_col + scaled_cols - 1;
% 在新图像中复制缩放后的部分
resized_image(start_row:end_row, start_col:end_col, :) = imresize(original_image, [scaled_rows, scaled_cols]);

% 显示结果
figure
imshow(attackimage);

% % 计算 PSNR 值
% psnrval= psnr(attackimage, Original);
% disp(['The PSNR value is ', num2str(psnrval)]);
% % 计算SSIM值
% ssimValue = ssim(attackimage, Original);
% disp(['嵌入水印图像的SSIM值为：', num2str(ssimValue)]);
%%
% for j=0.1
% attackimage = imnoise(watermarkedImage, 'speckle', j);
% attackimage= imnoise(watermarkedImage, 'gaussian', 0,j);
% attackimage = imnoise(watermarkedImage, 'salt & pepper', j);
% for j=3:2:5
% h = fspecial('gaussian', j);
% attackimage = imfilter(watermarkedImage, h);
% filter = fspecial('average', j);
% attackimage = imfilter(watermarkedImage, filter);
% for j=50
% quality = j;
% imwrite(watermarkedImage, 'compressed_watermark.jpg', 'Quality', quality);
% attackimage=imread('compressed_watermark.jpg');
% for j=10:10:60
% imwrite(watermarkedImage, 'compressed_image.jp2', 'jp2', 'Mode', 'lossy', 'CompressionRatio', 7);
% attackimage = imread('compressed_image.jp2');

recoveredYCbCr = rgb2ycbcr(attackimage12);
recoveredY = recoveredYCbCr(:,:,1);
recoveredY = double(recoveredY) + rounding_error;
recoveredCb = recoveredYCbCr(:,:,2);
recoveredCb = double(recoveredCb) + rounding_error2;
recoveredCr = recoveredYCbCr(:,:,3);
recoveredCr = double(recoveredCr) + rounding_error3;
% 进行整数小波变换的参数设置
wavelet = 'haar'; 
level = 1; 
doubleWImage = double(recoveredY);
[c, s1] = wavedec2(doubleWImage, level, wavelet);
cAw = appcoef2(c, s1, wavelet, level); 
[cHw, cVw, cDw] = detcoef2('all', c, s1, level); 
doubleWImage = double(cAw);
[c, s2] = wavedec2(doubleWImage, level, wavelet);
cAw2 = appcoef2(c, s2, wavelet, level); 
[cHw2, cVw2, cDw2] = detcoef2('all', c, s2, level); 
doubleWImage = double(cAw2);
[c, s3] = wavedec2(doubleWImage, level, wavelet);
cAw3 = appcoef2(c, s3, wavelet, level); 
[cHw3, cVw3, cDw3] = detcoef2('all', c, s3, level); 
%提取水印
[Uwex,Swex,Vwex] = svd(cAw3);
Swe = Uw * Swex * Vw';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Sh)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2 = waverec2([Wex, LHw2, HLw2, HHw2], l, wavelet);
reconstructedImage = waverec2([reconstructedImage2, LHw, HLw, HHw], s, wavelet);
% figure
% imshow(reconstructedImage)
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = U * Shor * V';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cHw3, cVw3, cDw3], s3, waveletName);
or_block2 = waverec2([or_block3, cHw2, cVw2, cDw2], s2, waveletName);
or_block = waverec2([or_block2, cHw, cVw, cDw], s1, waveletName);
recoveredYCbCr(:,:,1) = or_block ;


waveletName = 'haar'; 
level = 1; 
doubleImagecbw = double(recoveredCb);
[c, s1cbw] = wavedec2(doubleImagecbw, level, waveletName);
cAcbw = appcoef2(c, s1cbw, waveletName, level); 
[cHcbw, cVcbw, cDcbw] = detcoef2('all', c, s1cbw, level); 
doubleImagecbw = double(cAcbw);
[c, s2cbw] = wavedec2(doubleImagecbw, level, waveletName);
cA2cbw = appcoef2(c, s2cbw, waveletName, level); 
[cH2cbw, cV2cbw, cD2cbw] = detcoef2('all', c, s2cbw, level); 
doubleImagecbw = double(cA2cbw);
[c, s3cbw] = wavedec2(doubleImagecbw, level, waveletName);
cA3cbw = appcoef2(c, s3cbw, waveletName, level); 
[cH3cbw, cV3cbw, cD3cbw] = detcoef2('all', c, s3cbw, level); 

%提取水印
[Uwex,Swex,Vwex] = svd(cA3cbw);
Swe = Uwcb * Swex * Vwcb';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Shcb)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2g = waverec2([Wex, LHw2g, HLw2g, HHw2g], lg, wavelet);
reconstructedImageg = waverec2([reconstructedImage2g, LHwg, HLwg, HHwg], sg, wavelet);
% figure
% imshow(reconstructedImage)
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = Ucb * Shor * Vcb';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cH3cbw, cV3cbw, cD3cbw], s3cbw, waveletName);
or_block2 = waverec2([or_block3, cH2cbw, cV2cbw, cD2cbw], s2cbw, waveletName);
or_block = waverec2([or_block2, cHcbw, cVcbw, cDcbw], s1cbw, waveletName);
recoveredYCbCr(:,:,2) = or_block ;


waveletName = 'haar'; 
level = 1; 
doubleImagecrw = double(recoveredCr);
[c, s1crw] = wavedec2(doubleImagecrw, level, waveletName);
cAcrw = appcoef2(c, s1crw, waveletName, level); 
[cHcrw, cVcrw, cDcrw] = detcoef2('all', c, s1crw, level); 
doubleImagecrw = double(cAcrw);
[c, s2crw] = wavedec2(doubleImagecrw, level, waveletName);
cA2crw = appcoef2(c, s2crw, waveletName, level); 
[cH2crw, cV2crw, cD2crw] = detcoef2('all', c, s2crw, level); 
doubleImagecrw = double(cA2crw);
[c, s3crw] = wavedec2(doubleImagecrw, level, waveletName);
cA3crw = appcoef2(c, s3crw, waveletName, level); 
[cH3crw, cV3crw, cD3crw] = detcoef2('all', c, s3crw, level); 

%提取水印
[Uwex,Swex,Vwex] = svd(cA3crw);
Swe = Uwcr * Swex * Vwcr';
Sex = H *Swe;             %含水印的S奇异值矩阵
Whex = (Sex - Shcr)/alpha;  %经哈达玛变换的水印图像
Wex = inverseH * Whex;
% Wex = Ug * Sex * Vg;
reconstructedImage2b = waverec2([Wex, LHw2b, HLw2b, HHw2b], lb, wavelet);
reconstructedImageb = waverec2([reconstructedImage2b, LHwb, HLwb, HHwb], sb, wavelet);
% figure
% imshow(reconstructedImage)
%提取原始图像
Sor = Sex - alpha * Whex; %经哈达玛变换的原始图像S矩阵
Shor = inverseH * Sor;
orimage = Ucr * Shor * Vcr';
% figure
% imshow(orimage,[])
or_block3 = waverec2([orimage, cH3crw, cV3crw, cD3crw], s3crw, waveletName);
or_block2 = waverec2([or_block3, cH2crw, cV2crw, cD2crw], s2crw, waveletName);
or_block = waverec2([or_block2, cHcrw, cVcrw, cDcrw], s1crw, waveletName);
recoveredYCbCr(:,:,3) = or_block ;

originalImage = ycbcr2rgb(recoveredYCbCr);
figure
imshow(originalImage);title('恢复的原始图像');
% 计算 PSNR 值
psnrval= psnr(originalImage, Original);
disp(['The PSNR value is ', num2str(psnrval,'%.4f')]);
% % 计算SSIM值
% ssimValue = ssim(originalImage, Original);
% disp(['嵌入水印图像的SSIM值为：', num2str(ssimValue,'%.4f')]);

% 将水印图像还原
unscrambled_w = Unscramble(reconstructedImage);
unscrambled_wg = Unscramble(reconstructedImageg);
unscrambled_wb = Unscramble(reconstructedImageb);

% 读取置乱后的图像
scrambledImager = unscrambled_w;
[M, N] = size(scrambledImager);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImager = zeros(M, N, 'like', scrambledImager);
for i = 1:M
    for j = 1:N
        recoveredImager(grayCodeMatrix(i, j) + 1) = scrambledImager(i, j);
    end
end

% 读取置乱后的图像
scrambledImageg = unscrambled_wg;
[M, N] = size(scrambledImageg);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImageg = zeros(M, N, 'like', scrambledImageg);
for i = 1:M
    for j = 1:N
        recoveredImageg(grayCodeMatrix(i, j) + 1) = scrambledImageg(i, j);
    end
end

% 读取置乱后的图像
scrambledImageb = unscrambled_wb;
[M, N] = size(scrambledImageb);
% 生成广义Gray码序列
grayCodeSeq = gray2bin(0:(M*N-1), 'bam', log2(M*N));
% 将Gray码序列转为矩阵形式
grayCodeMatrix = reshape(bin2dec(grayCodeSeq), M, N);
% 对图像进行解乱
recoveredImageb = zeros(M, N, 'like', scrambledImageb);
for i = 1:M
    for j = 1:N
        recoveredImageb(grayCodeMatrix(i, j) + 1) = scrambledImageb(i, j);
    end
end

recoveredImage = uint8(cat(3,recoveredImager,recoveredImageg,recoveredImageb));
% 显示置乱后的图像和恢复后的图像
% figure;
% imshow(recoveredImage,[]), title('恢复后的图像');
% 计算提取水印和原始水印的标准差
std_extracted = std(double(recoveredImage(:)));
std_original = std(double(watermark(:)));
% 计算提取水印和原始水印的协方差矩阵
cov_matrix = cov(double(recoveredImage(:)), double(watermark(:)));
% 计算归一化相关系数（NC）值
NC = cov_matrix(1, 2) / (std_extracted * std_original);
% 显示 NC 值
disp(num2str(NC,'%.4f'));
% disp(['NC 值: ', num2str(NC,'%.4f')]);

% % 比较每个像素值并计算 BER
% originalImageGray = rgb2gray(watermark);
% extractedImageGray = rgb2gray(recoveredImage);
% % 将图像转换为二进制格式
% originalBinary = imbinarize(originalImageGray);
% extractedBinary = imbinarize(extractedImageGray);
% totalBits = numel(originalBinary) ;  % 总比特数
% errorBits = sum(sum(originalBinary ~= extractedBinary));  % 错误比特数
% BER = errorBits / totalBits;  % 比特误码率
% fprintf('提取水印图像的比特误码率（BER）：%.4f\n', BER);
% end
% end
%% 调用霜冰优化算法来寻找最佳的嵌入因子 alpha
% N = 50; % 种群规模
% Max_iter = 10; % 最大迭代次数
% lb = 0; % alpha 下界
% ub = 1; % alpha 上界
% dim = 1; % 维度
% [Best_alpha, Best_alpha_rate, Convergence_curve] = RIME(N, Max_iter, lb, ub, dim, @calculate_fitness);
% disp(['最佳嵌入因子 alpha: ', num2str(Best_alpha)]);
% disp(['对应的适应度值: ', num2str(Best_alpha_rate)]);
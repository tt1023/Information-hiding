% clear
% 定义 x 轴范围
x = linspace(0.01, 0.2, 39);
% 定义 y 轴数值
% y1 = [70.1256,63.2896,60.2946,58.0636,56.0989,54.4233,53.0458,51.6421,50.6132,49.6428,48.7764,48.0251,47.3005,46.6183,46.0023,45.387,44.8988,44.4399,43.9327,43.3953,42.9598,42.541,42.1345,41.706,41.321,40.8953,40.4646,40.1267,39.772,39.3748,39.0252,38.6841,38.3356,38.0074,37.6891,37.3585,37.0521,36.7477];
% y2 = [36.7705,36.7686,36.7603,36.7491,36.7306,36.7097,36.6853,36.6482,36.6163,36.5731,36.5252,36.4797,36.427,36.3695,36.3073,36.2348,36.1666,36.104,36.0258,35.9308,35.8466,35.7628,35.6701,35.5654,35.4635,35.3492,35.2216,35.1149,34.9946,34.8571,34.7259,34.5922,34.4482,34.3079,34.1643,34.0121,33.8636,33.7116];
Noattackdata = importdata('Noattack');
y1 = Noattackdata.data;
Mediandata = importdata('Median');
y2 = Mediandata.data;
Averagedata = importdata('Average');
y3 = Averagedata.data;
Gaussiandata = importdata('Gaussian');
y4 = Gaussiandata.data;
saltdata = importdata('salt');
y5 = saltdata.data;
Gnoisedata = importdata('Gnoise');
y6 = Gnoisedata.data;
Speckledata = importdata('Speckle');
y7 = Speckledata.data;
JPEGdata = importdata('JPEG');
y8 = JPEGdata.data;
JPEG2000data = importdata('JPEG2000');
y9 = JPEG2000data.data;
Sharpeningdata = importdata('Sharpening');
y10 = Sharpeningdata.data;
Histogramdata = importdata('Histogram');
y11 = Histogramdata.data;
Gammadata = importdata('Gamma');
y12 = Gammadata.data;

% 绘制折线图，使用不同的颜色和形状区分每条折线
figure;
hold on;
plot(x, y1, 'r-x', 'LineWidth', 0.7); 
plot(x, y2, 'c-^', 'LineWidth', 0.7); 
plot(x, y3, 'b-+', 'LineWidth', 0.7); 
plot(x, y4, 'g-o', 'LineWidth', 0.7); 
plot(x, y5, 'm-', 'Marker', 'hexagram', 'LineWidth', 0.7);
plot(x, y6, 'y-', 'Marker', '<', 'LineWidth', 0.7);
plot(x, y7, 'k-', 'Marker', '.', 'LineWidth', 0.7);
plot(x, y8, 'k-', 'Marker', 'square', 'LineWidth', 0.7);
plot(x, y9, 'm-', 'Marker', 'pentagram', 'LineWidth', 0.7);
plot(x, y10, 'c-', 'Marker', '>', 'LineWidth', 0.7);
plot(x, y11, 'g-', 'Marker', '.', 'LineWidth', 0.7);
plot(x, y12, 'y-', 'Marker', '.', 'LineWidth', 0.7);
% 设置图例和轴标签
legend('No Attack', 'Median filter', 'Average filter', 'Gaussian filter', 'Salt & peppers noise', 'Gaussian noise','Speckle noise','JPEG compression','JPEG2000 compression','Sharpening','Histogram equalization','Gamma correction'); % 图例
ylim([0, 80]);
yticks(0:10:80);
ylabel('PSNR value');
xlabel('scaling factor(α)'); % x 轴标签

% grid on;  % 显示网格线
% 将四周框起来
box on



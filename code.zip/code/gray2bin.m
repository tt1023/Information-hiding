% Gray码生成函数
function binary = gray2bin(decimal, type, bits)
    if strcmp(type, 'pam')
        binary = dec2bin(decimal, bits);
    elseif strcmp(type, 'bam')
        gray = bitxor(decimal, bitshift(decimal, -1));
        binary = dec2bin(gray, bits);
    else
        error('未知的Gray码类型');
    end
end


function [best_alpha, best_psnr] = SAO(grayImg, grayWatermark, alpha_lb, alpha_ub, max_iter, pop_size, elite_ratio)
    % 哈达玛变换矩阵和逆矩阵
    H = hadamard(64);
    inverseH = H' / 64;
    % 计算PSNR值的函数句柄
    obj_func = @(alpha) calculate_psnr(alpha, grayImg, grayWatermark, H, inverseH);
    % 初始化种群
    pop = rand(pop_size, 1) * (alpha_ub - alpha_lb) + alpha_lb;
    
    % 计算适应度并记录最佳解
    fitness = arrayfun(obj_func, pop);
    [best_fitness, best_idx] = max(fitness);
    best_alpha = pop(best_idx);
    best_psnr = best_fitness;
    
    % 迭代优化
    for iter = 1:max_iter
        % 雪融化模拟
        temperature = 1 - iter / max_iter; % 温度递减
        humidity = rand(); % 湿度随机
        random_factor = randn(pop_size, 1); % 随机因子
        new_pop = pop + temperature * humidity * random_factor;
        
        % 修正超出搜索空间的解
        new_pop(new_pop < alpha_lb) = alpha_lb;
        new_pop(new_pop > alpha_ub) = alpha_ub;
        
        % 更新精英解集合
        elite_size = round(pop_size * elite_ratio);
        [~, elite_idx] = sort(fitness, 'descend');
        elite_pool = pop(elite_idx(1:elite_size));
        elite_mean = mean(elite_pool);
        
        % 更新种群
        pop(1:elite_size) = elite_pool;
        pop(elite_size+1:end) = new_pop(elite_size+1:end);
        
        % 更新适应度和最佳解
        fitness = arrayfun(obj_func, pop);
        [max_fitness, max_idx] = max(fitness);
        if max_fitness > best_fitness
            best_fitness = max_fitness;
            best_alpha = pop(max_idx);
            best_psnr = best_fitness;
        end
        
        % 显示当前迭代结果
        fprintf('Best embedding strength: %.4f, Best PSNR: %.4f\n', best_alpha, best_psnr);
    end
end
% 计算嵌入水印图像的PSNR值
function psnr_alpha = calculate_psnr(alpha, grayImg, grayWatermark, H, inverseH)
    % 对图像进行SVD分解
    [U, S, V] = svd(grayImg);
    % 对S进行哈达玛变换
    Sh = H * S;
    hw = H * grayWatermark;
    % 嵌入水印图像
    Sh_watermarked = Sh + alpha * hw;
    % 逆哈达玛变换
    Sh_watermarked = inverseH * Sh_watermarked;
    % 嵌入水印后的图像逆SVD
    reconstructedImg = U * Sh_watermarked * V';
    % 计算PSNR值
    mse = sum(sum((grayImg - reconstructedImg) .^ 2)) / (size(grayImg, 1) * size(grayImg, 2));
    max_pixel_value = 255;  % 图像像素最大值
    psnr_alpha = 10 * log10(max_pixel_value^2 / mse);
end
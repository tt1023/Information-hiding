% clear
% 定义 x 轴范围
x = linspace(0.025, 0.2, 36);
% 定义 y 轴数值（示例中假设有六条折线）
housedata = importdata('house');
y1 = housedata.data;
baboondata = importdata('baboon');
y2 = baboondata.data;
Pepppersdata = importdata('peppers');
y3 = Pepppersdata.data;
Airplanedata = importdata('airplane');
y4 = Airplanedata.data;
Sailboatdata = importdata('sailboat');
y5 = Sailboatdata.data;
barbaradata = importdata('barbara');
y6 = barbaradata.data;

% 绘制折线图，使用不同的颜色和形状区分每条折线
figure;
hold on;
plot(x, y1, 'c-x', 'LineWidth', 0.7);
plot(x, y2, 'r-^', 'LineWidth', 0.7); 
plot(x, y3, 'g-+', 'LineWidth', 0.7); 
plot(x, y4, 'b-o', 'LineWidth', 0.7); 
plot(x, y5, 'y-', 'Marker', '>', 'LineWidth', 0.7); 
plot(x, y6, 'm-', 'Marker', 'pentagram', 'LineWidth', 0.7); 

% 设置图例和轴标签
legend('House', 'Baboon', 'Peppers', 'Airplane', 'Sailboat', 'Barbara'); % 图例
ylim([0, 100]);
yticks(0:10:100);
ylabel('PSNR value');
xlabel('scaling factor(α)'); % x 轴标签
set(gca,'FontName','Times New Roman');
% grid on;  % 显示网格线
% 将四周框起来
box on


